﻿namespace SerialPortListener
{
    partial class MainForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.order_box = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.total_boxex_box = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.sum_box = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.button_calcul = new System.Windows.Forms.Button();
            this.serialSettingsBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.textBox2 = new System.Windows.Forms.TextBox();
            this.textBox3 = new System.Windows.Forms.TextBox();
            this.textBox4 = new System.Windows.Forms.TextBox();
            this.textBox5 = new System.Windows.Forms.TextBox();
            this.textBox6 = new System.Windows.Forms.TextBox();
            this.textBox7 = new System.Windows.Forms.TextBox();
            this.textBox8 = new System.Windows.Forms.TextBox();
            this.textBox9 = new System.Windows.Forms.TextBox();
            this.textBox10 = new System.Windows.Forms.TextBox();
            this.textBox11 = new System.Windows.Forms.TextBox();
            this.textBox12 = new System.Windows.Forms.TextBox();
            this.textBox13 = new System.Windows.Forms.TextBox();
            this.textBox14 = new System.Windows.Forms.TextBox();
            this.textBox15 = new System.Windows.Forms.TextBox();
            this.textBox16 = new System.Windows.Forms.TextBox();
            this.textBox17 = new System.Windows.Forms.TextBox();
            this.textBox18 = new System.Windows.Forms.TextBox();
            this.textBox19 = new System.Windows.Forms.TextBox();
            this.textBox20 = new System.Windows.Forms.TextBox();
            this.textBox21 = new System.Windows.Forms.TextBox();
            this.textBox22 = new System.Windows.Forms.TextBox();
            this.textBox23 = new System.Windows.Forms.TextBox();
            this.textBox24 = new System.Windows.Forms.TextBox();
            this.textBox25 = new System.Windows.Forms.TextBox();
            this.textBox26 = new System.Windows.Forms.TextBox();
            this.textBox27 = new System.Windows.Forms.TextBox();
            this.textBox28 = new System.Windows.Forms.TextBox();
            this.textBox29 = new System.Windows.Forms.TextBox();
            this.textBox30 = new System.Windows.Forms.TextBox();
            this.textBox31 = new System.Windows.Forms.TextBox();
            this.textBox32 = new System.Windows.Forms.TextBox();
            this.textBox33 = new System.Windows.Forms.TextBox();
            this.textBox34 = new System.Windows.Forms.TextBox();
            this.textBox35 = new System.Windows.Forms.TextBox();
            this.textBox36 = new System.Windows.Forms.TextBox();
            this.textBox37 = new System.Windows.Forms.TextBox();
            this.textBox38 = new System.Windows.Forms.TextBox();
            this.textBox39 = new System.Windows.Forms.TextBox();
            this.textBox40 = new System.Windows.Forms.TextBox();
            this.textBox41 = new System.Windows.Forms.TextBox();
            this.textBox42 = new System.Windows.Forms.TextBox();
            this.textBox43 = new System.Windows.Forms.TextBox();
            this.textBox44 = new System.Windows.Forms.TextBox();
            this.textBox45 = new System.Windows.Forms.TextBox();
            this.textBox46 = new System.Windows.Forms.TextBox();
            this.textBox47 = new System.Windows.Forms.TextBox();
            this.textBox48 = new System.Windows.Forms.TextBox();
            this.textBox49 = new System.Windows.Forms.TextBox();
            this.textBox50 = new System.Windows.Forms.TextBox();
            this.textBox51 = new System.Windows.Forms.TextBox();
            this.textBox52 = new System.Windows.Forms.TextBox();
            this.textBox53 = new System.Windows.Forms.TextBox();
            this.textBox54 = new System.Windows.Forms.TextBox();
            this.textBox55 = new System.Windows.Forms.TextBox();
            this.textBox56 = new System.Windows.Forms.TextBox();
            this.textBox57 = new System.Windows.Forms.TextBox();
            this.textBox58 = new System.Windows.Forms.TextBox();
            this.textBox59 = new System.Windows.Forms.TextBox();
            this.textBox60 = new System.Windows.Forms.TextBox();
            this.textBox61 = new System.Windows.Forms.TextBox();
            this.textBox62 = new System.Windows.Forms.TextBox();
            this.textBox63 = new System.Windows.Forms.TextBox();
            this.textBox64 = new System.Windows.Forms.TextBox();
            this.textBox65 = new System.Windows.Forms.TextBox();
            this.textBox66 = new System.Windows.Forms.TextBox();
            this.textBox67 = new System.Windows.Forms.TextBox();
            this.textBox68 = new System.Windows.Forms.TextBox();
            this.textBox69 = new System.Windows.Forms.TextBox();
            this.textBox70 = new System.Windows.Forms.TextBox();
            this.textBox71 = new System.Windows.Forms.TextBox();
            this.textBox72 = new System.Windows.Forms.TextBox();
            this.textBox73 = new System.Windows.Forms.TextBox();
            this.textBox74 = new System.Windows.Forms.TextBox();
            this.textBox75 = new System.Windows.Forms.TextBox();
            this.textBox76 = new System.Windows.Forms.TextBox();
            this.textBox77 = new System.Windows.Forms.TextBox();
            this.textBox78 = new System.Windows.Forms.TextBox();
            this.textBox79 = new System.Windows.Forms.TextBox();
            this.textBox80 = new System.Windows.Forms.TextBox();
            this.textBox81 = new System.Windows.Forms.TextBox();
            this.textBox82 = new System.Windows.Forms.TextBox();
            this.textBox83 = new System.Windows.Forms.TextBox();
            this.textBox84 = new System.Windows.Forms.TextBox();
            this.textBox85 = new System.Windows.Forms.TextBox();
            this.textBox86 = new System.Windows.Forms.TextBox();
            this.textBox87 = new System.Windows.Forms.TextBox();
            this.textBox88 = new System.Windows.Forms.TextBox();
            this.textBox89 = new System.Windows.Forms.TextBox();
            this.textBox90 = new System.Windows.Forms.TextBox();
            this.textBox91 = new System.Windows.Forms.TextBox();
            this.textBox92 = new System.Windows.Forms.TextBox();
            this.textBox93 = new System.Windows.Forms.TextBox();
            this.textBox94 = new System.Windows.Forms.TextBox();
            this.textBox95 = new System.Windows.Forms.TextBox();
            this.textBox96 = new System.Windows.Forms.TextBox();
            this.textBox97 = new System.Windows.Forms.TextBox();
            this.textBox98 = new System.Windows.Forms.TextBox();
            this.textBox99 = new System.Windows.Forms.TextBox();
            this.textBox100 = new System.Windows.Forms.TextBox();
            this.textBox101 = new System.Windows.Forms.TextBox();
            this.textBox102 = new System.Windows.Forms.TextBox();
            this.textBox103 = new System.Windows.Forms.TextBox();
            this.textBox104 = new System.Windows.Forms.TextBox();
            this.textBox105 = new System.Windows.Forms.TextBox();
            this.textBox106 = new System.Windows.Forms.TextBox();
            this.textBox107 = new System.Windows.Forms.TextBox();
            this.textBox108 = new System.Windows.Forms.TextBox();
            this.textBox109 = new System.Windows.Forms.TextBox();
            this.textBox110 = new System.Windows.Forms.TextBox();
            this.textBox111 = new System.Windows.Forms.TextBox();
            this.textBox112 = new System.Windows.Forms.TextBox();
            this.textBox113 = new System.Windows.Forms.TextBox();
            this.textBox114 = new System.Windows.Forms.TextBox();
            this.textBox115 = new System.Windows.Forms.TextBox();
            this.textBox116 = new System.Windows.Forms.TextBox();
            this.textBox117 = new System.Windows.Forms.TextBox();
            this.textBox118 = new System.Windows.Forms.TextBox();
            this.textBox119 = new System.Windows.Forms.TextBox();
            this.textBox120 = new System.Windows.Forms.TextBox();
            this.textBox121 = new System.Windows.Forms.TextBox();
            this.textBox122 = new System.Windows.Forms.TextBox();
            this.textBox123 = new System.Windows.Forms.TextBox();
            this.textBox124 = new System.Windows.Forms.TextBox();
            this.textBox125 = new System.Windows.Forms.TextBox();
            this.textBox126 = new System.Windows.Forms.TextBox();
            this.textBox127 = new System.Windows.Forms.TextBox();
            this.textBox128 = new System.Windows.Forms.TextBox();
            this.textBox129 = new System.Windows.Forms.TextBox();
            this.textBox130 = new System.Windows.Forms.TextBox();
            this.textBox131 = new System.Windows.Forms.TextBox();
            this.textBox132 = new System.Windows.Forms.TextBox();
            this.textBox133 = new System.Windows.Forms.TextBox();
            this.textBox134 = new System.Windows.Forms.TextBox();
            this.textBox135 = new System.Windows.Forms.TextBox();
            this.textBox136 = new System.Windows.Forms.TextBox();
            this.textBox137 = new System.Windows.Forms.TextBox();
            this.textBox138 = new System.Windows.Forms.TextBox();
            this.textBox139 = new System.Windows.Forms.TextBox();
            this.textBox140 = new System.Windows.Forms.TextBox();
            this.textBox141 = new System.Windows.Forms.TextBox();
            this.textBox142 = new System.Windows.Forms.TextBox();
            this.textBox143 = new System.Windows.Forms.TextBox();
            this.textBox144 = new System.Windows.Forms.TextBox();
            this.textBox145 = new System.Windows.Forms.TextBox();
            this.textBox146 = new System.Windows.Forms.TextBox();
            this.textBox147 = new System.Windows.Forms.TextBox();
            this.textBox148 = new System.Windows.Forms.TextBox();
            this.textBox149 = new System.Windows.Forms.TextBox();
            this.textBox150 = new System.Windows.Forms.TextBox();
            this.textBox151 = new System.Windows.Forms.TextBox();
            this.textBox152 = new System.Windows.Forms.TextBox();
            this.textBox153 = new System.Windows.Forms.TextBox();
            this.textBox154 = new System.Windows.Forms.TextBox();
            this.textBox155 = new System.Windows.Forms.TextBox();
            this.textBox156 = new System.Windows.Forms.TextBox();
            this.textBox157 = new System.Windows.Forms.TextBox();
            this.textBox158 = new System.Windows.Forms.TextBox();
            this.textBox159 = new System.Windows.Forms.TextBox();
            this.textBox160 = new System.Windows.Forms.TextBox();
            this.textBox161 = new System.Windows.Forms.TextBox();
            this.textBox162 = new System.Windows.Forms.TextBox();
            this.textBox163 = new System.Windows.Forms.TextBox();
            this.textBox164 = new System.Windows.Forms.TextBox();
            this.textBox165 = new System.Windows.Forms.TextBox();
            this.textBox166 = new System.Windows.Forms.TextBox();
            this.textBox167 = new System.Windows.Forms.TextBox();
            this.textBox168 = new System.Windows.Forms.TextBox();
            this.textBox169 = new System.Windows.Forms.TextBox();
            this.textBox170 = new System.Windows.Forms.TextBox();
            this.textBox171 = new System.Windows.Forms.TextBox();
            this.textBox172 = new System.Windows.Forms.TextBox();
            this.textBox173 = new System.Windows.Forms.TextBox();
            this.textBox174 = new System.Windows.Forms.TextBox();
            this.textBox175 = new System.Windows.Forms.TextBox();
            this.textBox176 = new System.Windows.Forms.TextBox();
            this.textBox177 = new System.Windows.Forms.TextBox();
            this.textBox178 = new System.Windows.Forms.TextBox();
            this.textBox179 = new System.Windows.Forms.TextBox();
            this.textBox180 = new System.Windows.Forms.TextBox();
            this.textBox181 = new System.Windows.Forms.TextBox();
            this.textBox182 = new System.Windows.Forms.TextBox();
            this.textBox183 = new System.Windows.Forms.TextBox();
            this.textBox184 = new System.Windows.Forms.TextBox();
            this.textBox185 = new System.Windows.Forms.TextBox();
            this.textBox186 = new System.Windows.Forms.TextBox();
            this.textBox187 = new System.Windows.Forms.TextBox();
            this.textBox188 = new System.Windows.Forms.TextBox();
            this.textBox189 = new System.Windows.Forms.TextBox();
            this.textBox190 = new System.Windows.Forms.TextBox();
            this.textBox191 = new System.Windows.Forms.TextBox();
            this.textBox192 = new System.Windows.Forms.TextBox();
            this.textBox193 = new System.Windows.Forms.TextBox();
            this.textBox194 = new System.Windows.Forms.TextBox();
            this.textBox195 = new System.Windows.Forms.TextBox();
            this.textBox196 = new System.Windows.Forms.TextBox();
            this.textBox197 = new System.Windows.Forms.TextBox();
            this.textBox198 = new System.Windows.Forms.TextBox();
            this.textBox199 = new System.Windows.Forms.TextBox();
            this.textBox200 = new System.Windows.Forms.TextBox();
            this.textBox201 = new System.Windows.Forms.TextBox();
            this.textBox202 = new System.Windows.Forms.TextBox();
            this.textBox203 = new System.Windows.Forms.TextBox();
            this.textBox204 = new System.Windows.Forms.TextBox();
            this.textBox205 = new System.Windows.Forms.TextBox();
            this.textBox206 = new System.Windows.Forms.TextBox();
            this.textBox207 = new System.Windows.Forms.TextBox();
            this.textBox208 = new System.Windows.Forms.TextBox();
            this.textBox209 = new System.Windows.Forms.TextBox();
            this.textBox210 = new System.Windows.Forms.TextBox();
            this.textBox211 = new System.Windows.Forms.TextBox();
            this.textBox212 = new System.Windows.Forms.TextBox();
            this.textBox213 = new System.Windows.Forms.TextBox();
            this.textBox214 = new System.Windows.Forms.TextBox();
            this.textBox215 = new System.Windows.Forms.TextBox();
            this.textBox216 = new System.Windows.Forms.TextBox();
            this.textBox217 = new System.Windows.Forms.TextBox();
            this.textBox218 = new System.Windows.Forms.TextBox();
            this.textBox219 = new System.Windows.Forms.TextBox();
            this.textBox220 = new System.Windows.Forms.TextBox();
            this.textBox221 = new System.Windows.Forms.TextBox();
            this.textBox222 = new System.Windows.Forms.TextBox();
            this.textBox223 = new System.Windows.Forms.TextBox();
            this.textBox224 = new System.Windows.Forms.TextBox();
            this.textBox225 = new System.Windows.Forms.TextBox();
            ((System.ComponentModel.ISupportInitialize)(this.serialSettingsBindingSource)).BeginInit();
            this.SuspendLayout();
            // 
            // order_box
            // 
            this.order_box.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.order_box.Location = new System.Drawing.Point(18, 35);
            this.order_box.Name = "order_box";
            this.order_box.Size = new System.Drawing.Size(95, 22);
            this.order_box.TabIndex = 17;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(15, 14);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(40, 16);
            this.label1.TabIndex = 21;
            this.label1.Text = "Ordre";
            // 
            // total_boxex_box
            // 
            this.total_boxex_box.BackColor = System.Drawing.SystemColors.Info;
            this.total_boxex_box.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.total_boxex_box.Location = new System.Drawing.Point(209, 60);
            this.total_boxex_box.Name = "total_boxex_box";
            this.total_boxex_box.ReadOnly = true;
            this.total_boxex_box.Size = new System.Drawing.Size(87, 22);
            this.total_boxex_box.TabIndex = 25;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(159, 63);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(44, 16);
            this.label3.TabIndex = 26;
            this.label3.Text = "de 1 à";
            // 
            // sum_box
            // 
            this.sum_box.BackColor = System.Drawing.SystemColors.Info;
            this.sum_box.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.sum_box.Location = new System.Drawing.Point(209, 35);
            this.sum_box.Name = "sum_box";
            this.sum_box.ReadOnly = true;
            this.sum_box.Size = new System.Drawing.Size(87, 22);
            this.sum_box.TabIndex = 23;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(205, 14);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(67, 16);
            this.label2.TabIndex = 24;
            this.label2.Text = "Constante";
            // 
            // button_calcul
            // 
            this.button_calcul.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button_calcul.Location = new System.Drawing.Point(19, 103);
            this.button_calcul.Name = "button_calcul";
            this.button_calcul.Size = new System.Drawing.Size(75, 27);
            this.button_calcul.TabIndex = 22;
            this.button_calcul.Text = "Calcul";
            this.button_calcul.UseVisualStyleBackColor = true;
            this.button_calcul.Click += new System.EventHandler(this.button_calcul_Click);
            // 
            // textBox1
            // 
            this.textBox1.BackColor = System.Drawing.Color.Cornsilk;
            this.textBox1.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox1.Location = new System.Drawing.Point(12, 146);
            this.textBox1.Name = "textBox1";
            this.textBox1.ReadOnly = true;
            this.textBox1.Size = new System.Drawing.Size(40, 22);
            this.textBox1.TabIndex = 36;
            this.textBox1.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.textBox1.Visible = false;
            // 
            // textBox2
            // 
            this.textBox2.BackColor = System.Drawing.Color.Cornsilk;
            this.textBox2.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox2.Location = new System.Drawing.Point(67, 146);
            this.textBox2.Name = "textBox2";
            this.textBox2.ReadOnly = true;
            this.textBox2.Size = new System.Drawing.Size(40, 22);
            this.textBox2.TabIndex = 37;
            this.textBox2.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.textBox2.Visible = false;
            // 
            // textBox3
            // 
            this.textBox3.BackColor = System.Drawing.Color.Cornsilk;
            this.textBox3.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox3.Location = new System.Drawing.Point(122, 146);
            this.textBox3.Name = "textBox3";
            this.textBox3.ReadOnly = true;
            this.textBox3.Size = new System.Drawing.Size(40, 22);
            this.textBox3.TabIndex = 38;
            this.textBox3.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.textBox3.Visible = false;
            // 
            // textBox4
            // 
            this.textBox4.BackColor = System.Drawing.Color.Cornsilk;
            this.textBox4.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox4.Location = new System.Drawing.Point(177, 146);
            this.textBox4.Name = "textBox4";
            this.textBox4.ReadOnly = true;
            this.textBox4.Size = new System.Drawing.Size(40, 22);
            this.textBox4.TabIndex = 39;
            this.textBox4.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.textBox4.Visible = false;
            // 
            // textBox5
            // 
            this.textBox5.BackColor = System.Drawing.Color.Cornsilk;
            this.textBox5.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox5.Location = new System.Drawing.Point(232, 146);
            this.textBox5.Name = "textBox5";
            this.textBox5.ReadOnly = true;
            this.textBox5.Size = new System.Drawing.Size(40, 22);
            this.textBox5.TabIndex = 40;
            this.textBox5.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.textBox5.Visible = false;
            // 
            // textBox6
            // 
            this.textBox6.BackColor = System.Drawing.Color.Cornsilk;
            this.textBox6.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox6.Location = new System.Drawing.Point(287, 146);
            this.textBox6.Name = "textBox6";
            this.textBox6.ReadOnly = true;
            this.textBox6.Size = new System.Drawing.Size(40, 22);
            this.textBox6.TabIndex = 41;
            this.textBox6.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.textBox6.Visible = false;
            // 
            // textBox7
            // 
            this.textBox7.BackColor = System.Drawing.Color.Cornsilk;
            this.textBox7.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox7.Location = new System.Drawing.Point(342, 146);
            this.textBox7.Name = "textBox7";
            this.textBox7.ReadOnly = true;
            this.textBox7.Size = new System.Drawing.Size(40, 22);
            this.textBox7.TabIndex = 42;
            this.textBox7.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.textBox7.Visible = false;
            // 
            // textBox8
            // 
            this.textBox8.BackColor = System.Drawing.Color.Cornsilk;
            this.textBox8.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox8.Location = new System.Drawing.Point(397, 146);
            this.textBox8.Name = "textBox8";
            this.textBox8.ReadOnly = true;
            this.textBox8.Size = new System.Drawing.Size(40, 22);
            this.textBox8.TabIndex = 43;
            this.textBox8.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.textBox8.Visible = false;
            // 
            // textBox9
            // 
            this.textBox9.BackColor = System.Drawing.Color.Cornsilk;
            this.textBox9.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox9.Location = new System.Drawing.Point(452, 146);
            this.textBox9.Name = "textBox9";
            this.textBox9.ReadOnly = true;
            this.textBox9.Size = new System.Drawing.Size(40, 22);
            this.textBox9.TabIndex = 44;
            this.textBox9.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.textBox9.Visible = false;
            // 
            // textBox10
            // 
            this.textBox10.BackColor = System.Drawing.Color.Cornsilk;
            this.textBox10.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox10.Location = new System.Drawing.Point(507, 146);
            this.textBox10.Name = "textBox10";
            this.textBox10.ReadOnly = true;
            this.textBox10.Size = new System.Drawing.Size(40, 22);
            this.textBox10.TabIndex = 45;
            this.textBox10.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.textBox10.Visible = false;
            // 
            // textBox11
            // 
            this.textBox11.BackColor = System.Drawing.Color.Cornsilk;
            this.textBox11.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox11.Location = new System.Drawing.Point(562, 146);
            this.textBox11.Name = "textBox11";
            this.textBox11.ReadOnly = true;
            this.textBox11.Size = new System.Drawing.Size(40, 22);
            this.textBox11.TabIndex = 46;
            this.textBox11.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.textBox11.Visible = false;
            // 
            // textBox12
            // 
            this.textBox12.BackColor = System.Drawing.Color.Cornsilk;
            this.textBox12.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox12.Location = new System.Drawing.Point(617, 146);
            this.textBox12.Name = "textBox12";
            this.textBox12.ReadOnly = true;
            this.textBox12.Size = new System.Drawing.Size(40, 22);
            this.textBox12.TabIndex = 47;
            this.textBox12.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.textBox12.Visible = false;
            // 
            // textBox13
            // 
            this.textBox13.BackColor = System.Drawing.Color.Cornsilk;
            this.textBox13.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox13.Location = new System.Drawing.Point(672, 146);
            this.textBox13.Name = "textBox13";
            this.textBox13.ReadOnly = true;
            this.textBox13.Size = new System.Drawing.Size(40, 22);
            this.textBox13.TabIndex = 48;
            this.textBox13.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.textBox13.Visible = false;
            // 
            // textBox14
            // 
            this.textBox14.BackColor = System.Drawing.Color.Cornsilk;
            this.textBox14.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox14.Location = new System.Drawing.Point(727, 146);
            this.textBox14.Name = "textBox14";
            this.textBox14.ReadOnly = true;
            this.textBox14.Size = new System.Drawing.Size(40, 22);
            this.textBox14.TabIndex = 49;
            this.textBox14.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.textBox14.Visible = false;
            // 
            // textBox15
            // 
            this.textBox15.BackColor = System.Drawing.Color.Cornsilk;
            this.textBox15.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox15.Location = new System.Drawing.Point(782, 146);
            this.textBox15.Name = "textBox15";
            this.textBox15.ReadOnly = true;
            this.textBox15.Size = new System.Drawing.Size(40, 22);
            this.textBox15.TabIndex = 53;
            this.textBox15.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.textBox15.Visible = false;
            // 
            // textBox16
            // 
            this.textBox16.BackColor = System.Drawing.Color.Cornsilk;
            this.textBox16.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox16.Location = new System.Drawing.Point(12, 174);
            this.textBox16.Name = "textBox16";
            this.textBox16.ReadOnly = true;
            this.textBox16.Size = new System.Drawing.Size(40, 22);
            this.textBox16.TabIndex = 54;
            this.textBox16.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.textBox16.Visible = false;
            // 
            // textBox17
            // 
            this.textBox17.BackColor = System.Drawing.Color.Cornsilk;
            this.textBox17.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox17.Location = new System.Drawing.Point(67, 174);
            this.textBox17.Name = "textBox17";
            this.textBox17.ReadOnly = true;
            this.textBox17.Size = new System.Drawing.Size(40, 22);
            this.textBox17.TabIndex = 55;
            this.textBox17.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.textBox17.Visible = false;
            // 
            // textBox18
            // 
            this.textBox18.BackColor = System.Drawing.Color.Cornsilk;
            this.textBox18.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox18.Location = new System.Drawing.Point(122, 174);
            this.textBox18.Name = "textBox18";
            this.textBox18.ReadOnly = true;
            this.textBox18.Size = new System.Drawing.Size(40, 22);
            this.textBox18.TabIndex = 56;
            this.textBox18.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.textBox18.Visible = false;
            // 
            // textBox19
            // 
            this.textBox19.BackColor = System.Drawing.Color.Cornsilk;
            this.textBox19.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox19.Location = new System.Drawing.Point(177, 174);
            this.textBox19.Name = "textBox19";
            this.textBox19.ReadOnly = true;
            this.textBox19.Size = new System.Drawing.Size(40, 22);
            this.textBox19.TabIndex = 57;
            this.textBox19.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.textBox19.Visible = false;
            // 
            // textBox20
            // 
            this.textBox20.BackColor = System.Drawing.Color.Cornsilk;
            this.textBox20.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox20.Location = new System.Drawing.Point(232, 174);
            this.textBox20.Name = "textBox20";
            this.textBox20.ReadOnly = true;
            this.textBox20.Size = new System.Drawing.Size(40, 22);
            this.textBox20.TabIndex = 58;
            this.textBox20.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.textBox20.Visible = false;
            // 
            // textBox21
            // 
            this.textBox21.BackColor = System.Drawing.Color.Cornsilk;
            this.textBox21.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox21.Location = new System.Drawing.Point(287, 174);
            this.textBox21.Name = "textBox21";
            this.textBox21.ReadOnly = true;
            this.textBox21.Size = new System.Drawing.Size(40, 22);
            this.textBox21.TabIndex = 59;
            this.textBox21.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.textBox21.Visible = false;
            // 
            // textBox22
            // 
            this.textBox22.BackColor = System.Drawing.Color.Cornsilk;
            this.textBox22.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox22.Location = new System.Drawing.Point(342, 174);
            this.textBox22.Name = "textBox22";
            this.textBox22.ReadOnly = true;
            this.textBox22.Size = new System.Drawing.Size(40, 22);
            this.textBox22.TabIndex = 60;
            this.textBox22.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.textBox22.Visible = false;
            // 
            // textBox23
            // 
            this.textBox23.BackColor = System.Drawing.Color.Cornsilk;
            this.textBox23.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox23.Location = new System.Drawing.Point(397, 174);
            this.textBox23.Name = "textBox23";
            this.textBox23.ReadOnly = true;
            this.textBox23.Size = new System.Drawing.Size(40, 22);
            this.textBox23.TabIndex = 61;
            this.textBox23.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.textBox23.Visible = false;
            // 
            // textBox24
            // 
            this.textBox24.BackColor = System.Drawing.Color.Cornsilk;
            this.textBox24.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox24.Location = new System.Drawing.Point(452, 174);
            this.textBox24.Name = "textBox24";
            this.textBox24.ReadOnly = true;
            this.textBox24.Size = new System.Drawing.Size(40, 22);
            this.textBox24.TabIndex = 62;
            this.textBox24.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.textBox24.Visible = false;
            // 
            // textBox25
            // 
            this.textBox25.BackColor = System.Drawing.Color.Cornsilk;
            this.textBox25.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox25.Location = new System.Drawing.Point(507, 174);
            this.textBox25.Name = "textBox25";
            this.textBox25.ReadOnly = true;
            this.textBox25.Size = new System.Drawing.Size(40, 22);
            this.textBox25.TabIndex = 63;
            this.textBox25.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.textBox25.Visible = false;
            // 
            // textBox26
            // 
            this.textBox26.BackColor = System.Drawing.Color.Cornsilk;
            this.textBox26.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox26.Location = new System.Drawing.Point(562, 174);
            this.textBox26.Name = "textBox26";
            this.textBox26.ReadOnly = true;
            this.textBox26.Size = new System.Drawing.Size(40, 22);
            this.textBox26.TabIndex = 64;
            this.textBox26.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.textBox26.Visible = false;
            // 
            // textBox27
            // 
            this.textBox27.BackColor = System.Drawing.Color.Cornsilk;
            this.textBox27.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox27.Location = new System.Drawing.Point(617, 174);
            this.textBox27.Name = "textBox27";
            this.textBox27.ReadOnly = true;
            this.textBox27.Size = new System.Drawing.Size(40, 22);
            this.textBox27.TabIndex = 65;
            this.textBox27.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.textBox27.Visible = false;
            // 
            // textBox28
            // 
            this.textBox28.BackColor = System.Drawing.Color.Cornsilk;
            this.textBox28.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox28.Location = new System.Drawing.Point(672, 174);
            this.textBox28.Name = "textBox28";
            this.textBox28.ReadOnly = true;
            this.textBox28.Size = new System.Drawing.Size(40, 22);
            this.textBox28.TabIndex = 66;
            this.textBox28.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.textBox28.Visible = false;
            // 
            // textBox29
            // 
            this.textBox29.BackColor = System.Drawing.Color.Cornsilk;
            this.textBox29.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox29.Location = new System.Drawing.Point(727, 174);
            this.textBox29.Name = "textBox29";
            this.textBox29.ReadOnly = true;
            this.textBox29.Size = new System.Drawing.Size(40, 22);
            this.textBox29.TabIndex = 67;
            this.textBox29.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.textBox29.Visible = false;
            // 
            // textBox30
            // 
            this.textBox30.BackColor = System.Drawing.Color.Cornsilk;
            this.textBox30.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox30.Location = new System.Drawing.Point(783, 174);
            this.textBox30.Name = "textBox30";
            this.textBox30.ReadOnly = true;
            this.textBox30.Size = new System.Drawing.Size(40, 22);
            this.textBox30.TabIndex = 68;
            this.textBox30.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.textBox30.Visible = false;
            // 
            // textBox31
            // 
            this.textBox31.BackColor = System.Drawing.Color.Cornsilk;
            this.textBox31.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox31.Location = new System.Drawing.Point(12, 202);
            this.textBox31.Name = "textBox31";
            this.textBox31.ReadOnly = true;
            this.textBox31.Size = new System.Drawing.Size(40, 22);
            this.textBox31.TabIndex = 69;
            this.textBox31.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.textBox31.Visible = false;
            // 
            // textBox32
            // 
            this.textBox32.BackColor = System.Drawing.Color.Cornsilk;
            this.textBox32.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox32.Location = new System.Drawing.Point(67, 202);
            this.textBox32.Name = "textBox32";
            this.textBox32.ReadOnly = true;
            this.textBox32.Size = new System.Drawing.Size(40, 22);
            this.textBox32.TabIndex = 70;
            this.textBox32.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.textBox32.Visible = false;
            // 
            // textBox33
            // 
            this.textBox33.BackColor = System.Drawing.Color.Cornsilk;
            this.textBox33.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox33.Location = new System.Drawing.Point(122, 202);
            this.textBox33.Name = "textBox33";
            this.textBox33.ReadOnly = true;
            this.textBox33.Size = new System.Drawing.Size(40, 22);
            this.textBox33.TabIndex = 71;
            this.textBox33.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.textBox33.Visible = false;
            // 
            // textBox34
            // 
            this.textBox34.BackColor = System.Drawing.Color.Cornsilk;
            this.textBox34.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox34.Location = new System.Drawing.Point(177, 202);
            this.textBox34.Name = "textBox34";
            this.textBox34.ReadOnly = true;
            this.textBox34.Size = new System.Drawing.Size(40, 22);
            this.textBox34.TabIndex = 72;
            this.textBox34.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.textBox34.Visible = false;
            // 
            // textBox35
            // 
            this.textBox35.BackColor = System.Drawing.Color.Cornsilk;
            this.textBox35.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox35.Location = new System.Drawing.Point(232, 202);
            this.textBox35.Name = "textBox35";
            this.textBox35.ReadOnly = true;
            this.textBox35.Size = new System.Drawing.Size(40, 22);
            this.textBox35.TabIndex = 73;
            this.textBox35.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.textBox35.Visible = false;
            // 
            // textBox36
            // 
            this.textBox36.BackColor = System.Drawing.Color.Cornsilk;
            this.textBox36.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox36.Location = new System.Drawing.Point(287, 202);
            this.textBox36.Name = "textBox36";
            this.textBox36.ReadOnly = true;
            this.textBox36.Size = new System.Drawing.Size(40, 22);
            this.textBox36.TabIndex = 74;
            this.textBox36.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.textBox36.Visible = false;
            // 
            // textBox37
            // 
            this.textBox37.BackColor = System.Drawing.Color.Cornsilk;
            this.textBox37.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox37.Location = new System.Drawing.Point(342, 202);
            this.textBox37.Name = "textBox37";
            this.textBox37.ReadOnly = true;
            this.textBox37.Size = new System.Drawing.Size(40, 22);
            this.textBox37.TabIndex = 75;
            this.textBox37.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.textBox37.Visible = false;
            // 
            // textBox38
            // 
            this.textBox38.BackColor = System.Drawing.Color.Cornsilk;
            this.textBox38.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox38.Location = new System.Drawing.Point(397, 202);
            this.textBox38.Name = "textBox38";
            this.textBox38.ReadOnly = true;
            this.textBox38.Size = new System.Drawing.Size(40, 22);
            this.textBox38.TabIndex = 76;
            this.textBox38.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.textBox38.Visible = false;
            // 
            // textBox39
            // 
            this.textBox39.BackColor = System.Drawing.Color.Cornsilk;
            this.textBox39.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox39.Location = new System.Drawing.Point(452, 202);
            this.textBox39.Name = "textBox39";
            this.textBox39.ReadOnly = true;
            this.textBox39.Size = new System.Drawing.Size(40, 22);
            this.textBox39.TabIndex = 77;
            this.textBox39.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.textBox39.Visible = false;
            // 
            // textBox40
            // 
            this.textBox40.BackColor = System.Drawing.Color.Cornsilk;
            this.textBox40.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox40.Location = new System.Drawing.Point(507, 202);
            this.textBox40.Name = "textBox40";
            this.textBox40.ReadOnly = true;
            this.textBox40.Size = new System.Drawing.Size(40, 22);
            this.textBox40.TabIndex = 78;
            this.textBox40.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.textBox40.Visible = false;
            // 
            // textBox41
            // 
            this.textBox41.BackColor = System.Drawing.Color.Cornsilk;
            this.textBox41.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox41.Location = new System.Drawing.Point(562, 202);
            this.textBox41.Name = "textBox41";
            this.textBox41.ReadOnly = true;
            this.textBox41.Size = new System.Drawing.Size(40, 22);
            this.textBox41.TabIndex = 79;
            this.textBox41.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.textBox41.Visible = false;
            // 
            // textBox42
            // 
            this.textBox42.BackColor = System.Drawing.Color.Cornsilk;
            this.textBox42.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox42.Location = new System.Drawing.Point(617, 202);
            this.textBox42.Name = "textBox42";
            this.textBox42.ReadOnly = true;
            this.textBox42.Size = new System.Drawing.Size(40, 22);
            this.textBox42.TabIndex = 80;
            this.textBox42.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.textBox42.Visible = false;
            // 
            // textBox43
            // 
            this.textBox43.BackColor = System.Drawing.Color.Cornsilk;
            this.textBox43.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox43.Location = new System.Drawing.Point(672, 202);
            this.textBox43.Name = "textBox43";
            this.textBox43.ReadOnly = true;
            this.textBox43.Size = new System.Drawing.Size(40, 22);
            this.textBox43.TabIndex = 81;
            this.textBox43.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.textBox43.Visible = false;
            // 
            // textBox44
            // 
            this.textBox44.BackColor = System.Drawing.Color.Cornsilk;
            this.textBox44.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox44.Location = new System.Drawing.Point(727, 202);
            this.textBox44.Name = "textBox44";
            this.textBox44.ReadOnly = true;
            this.textBox44.Size = new System.Drawing.Size(40, 22);
            this.textBox44.TabIndex = 82;
            this.textBox44.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.textBox44.Visible = false;
            // 
            // textBox45
            // 
            this.textBox45.BackColor = System.Drawing.Color.Cornsilk;
            this.textBox45.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox45.Location = new System.Drawing.Point(783, 202);
            this.textBox45.Name = "textBox45";
            this.textBox45.ReadOnly = true;
            this.textBox45.Size = new System.Drawing.Size(40, 22);
            this.textBox45.TabIndex = 83;
            this.textBox45.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.textBox45.Visible = false;
            // 
            // textBox46
            // 
            this.textBox46.BackColor = System.Drawing.Color.Cornsilk;
            this.textBox46.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox46.Location = new System.Drawing.Point(12, 230);
            this.textBox46.Name = "textBox46";
            this.textBox46.ReadOnly = true;
            this.textBox46.Size = new System.Drawing.Size(40, 22);
            this.textBox46.TabIndex = 84;
            this.textBox46.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.textBox46.Visible = false;
            // 
            // textBox47
            // 
            this.textBox47.BackColor = System.Drawing.Color.Cornsilk;
            this.textBox47.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox47.Location = new System.Drawing.Point(67, 230);
            this.textBox47.Name = "textBox47";
            this.textBox47.ReadOnly = true;
            this.textBox47.Size = new System.Drawing.Size(40, 22);
            this.textBox47.TabIndex = 85;
            this.textBox47.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.textBox47.Visible = false;
            // 
            // textBox48
            // 
            this.textBox48.BackColor = System.Drawing.Color.Cornsilk;
            this.textBox48.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox48.Location = new System.Drawing.Point(122, 230);
            this.textBox48.Name = "textBox48";
            this.textBox48.ReadOnly = true;
            this.textBox48.Size = new System.Drawing.Size(40, 22);
            this.textBox48.TabIndex = 86;
            this.textBox48.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.textBox48.Visible = false;
            // 
            // textBox49
            // 
            this.textBox49.BackColor = System.Drawing.Color.Cornsilk;
            this.textBox49.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox49.Location = new System.Drawing.Point(177, 230);
            this.textBox49.Name = "textBox49";
            this.textBox49.ReadOnly = true;
            this.textBox49.Size = new System.Drawing.Size(40, 22);
            this.textBox49.TabIndex = 87;
            this.textBox49.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.textBox49.Visible = false;
            // 
            // textBox50
            // 
            this.textBox50.BackColor = System.Drawing.Color.Cornsilk;
            this.textBox50.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox50.Location = new System.Drawing.Point(232, 230);
            this.textBox50.Name = "textBox50";
            this.textBox50.ReadOnly = true;
            this.textBox50.Size = new System.Drawing.Size(40, 22);
            this.textBox50.TabIndex = 88;
            this.textBox50.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.textBox50.Visible = false;
            // 
            // textBox51
            // 
            this.textBox51.BackColor = System.Drawing.Color.Cornsilk;
            this.textBox51.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox51.Location = new System.Drawing.Point(287, 230);
            this.textBox51.Name = "textBox51";
            this.textBox51.ReadOnly = true;
            this.textBox51.Size = new System.Drawing.Size(40, 22);
            this.textBox51.TabIndex = 89;
            this.textBox51.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.textBox51.Visible = false;
            // 
            // textBox52
            // 
            this.textBox52.BackColor = System.Drawing.Color.Cornsilk;
            this.textBox52.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox52.Location = new System.Drawing.Point(342, 230);
            this.textBox52.Name = "textBox52";
            this.textBox52.ReadOnly = true;
            this.textBox52.Size = new System.Drawing.Size(40, 22);
            this.textBox52.TabIndex = 90;
            this.textBox52.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.textBox52.Visible = false;
            // 
            // textBox53
            // 
            this.textBox53.BackColor = System.Drawing.Color.Cornsilk;
            this.textBox53.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox53.Location = new System.Drawing.Point(397, 230);
            this.textBox53.Name = "textBox53";
            this.textBox53.ReadOnly = true;
            this.textBox53.Size = new System.Drawing.Size(40, 22);
            this.textBox53.TabIndex = 91;
            this.textBox53.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.textBox53.Visible = false;
            // 
            // textBox54
            // 
            this.textBox54.BackColor = System.Drawing.Color.Cornsilk;
            this.textBox54.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox54.Location = new System.Drawing.Point(452, 230);
            this.textBox54.Name = "textBox54";
            this.textBox54.ReadOnly = true;
            this.textBox54.Size = new System.Drawing.Size(40, 22);
            this.textBox54.TabIndex = 92;
            this.textBox54.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.textBox54.Visible = false;
            // 
            // textBox55
            // 
            this.textBox55.BackColor = System.Drawing.Color.Cornsilk;
            this.textBox55.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox55.Location = new System.Drawing.Point(507, 230);
            this.textBox55.Name = "textBox55";
            this.textBox55.ReadOnly = true;
            this.textBox55.Size = new System.Drawing.Size(40, 22);
            this.textBox55.TabIndex = 93;
            this.textBox55.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.textBox55.Visible = false;
            // 
            // textBox56
            // 
            this.textBox56.BackColor = System.Drawing.Color.Cornsilk;
            this.textBox56.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox56.Location = new System.Drawing.Point(562, 230);
            this.textBox56.Name = "textBox56";
            this.textBox56.ReadOnly = true;
            this.textBox56.Size = new System.Drawing.Size(40, 22);
            this.textBox56.TabIndex = 94;
            this.textBox56.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.textBox56.Visible = false;
            // 
            // textBox57
            // 
            this.textBox57.BackColor = System.Drawing.Color.Cornsilk;
            this.textBox57.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox57.Location = new System.Drawing.Point(617, 230);
            this.textBox57.Name = "textBox57";
            this.textBox57.ReadOnly = true;
            this.textBox57.Size = new System.Drawing.Size(40, 22);
            this.textBox57.TabIndex = 95;
            this.textBox57.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.textBox57.Visible = false;
            // 
            // textBox58
            // 
            this.textBox58.BackColor = System.Drawing.Color.Cornsilk;
            this.textBox58.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox58.Location = new System.Drawing.Point(672, 230);
            this.textBox58.Name = "textBox58";
            this.textBox58.ReadOnly = true;
            this.textBox58.Size = new System.Drawing.Size(40, 22);
            this.textBox58.TabIndex = 96;
            this.textBox58.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.textBox58.Visible = false;
            // 
            // textBox59
            // 
            this.textBox59.BackColor = System.Drawing.Color.Cornsilk;
            this.textBox59.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox59.Location = new System.Drawing.Point(727, 230);
            this.textBox59.Name = "textBox59";
            this.textBox59.ReadOnly = true;
            this.textBox59.Size = new System.Drawing.Size(40, 22);
            this.textBox59.TabIndex = 97;
            this.textBox59.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.textBox59.Visible = false;
            // 
            // textBox60
            // 
            this.textBox60.BackColor = System.Drawing.Color.Cornsilk;
            this.textBox60.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox60.Location = new System.Drawing.Point(783, 230);
            this.textBox60.Name = "textBox60";
            this.textBox60.ReadOnly = true;
            this.textBox60.Size = new System.Drawing.Size(40, 22);
            this.textBox60.TabIndex = 98;
            this.textBox60.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.textBox60.Visible = false;
            // 
            // textBox61
            // 
            this.textBox61.BackColor = System.Drawing.Color.Cornsilk;
            this.textBox61.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox61.Location = new System.Drawing.Point(12, 258);
            this.textBox61.Name = "textBox61";
            this.textBox61.ReadOnly = true;
            this.textBox61.Size = new System.Drawing.Size(40, 22);
            this.textBox61.TabIndex = 99;
            this.textBox61.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.textBox61.Visible = false;
            // 
            // textBox62
            // 
            this.textBox62.BackColor = System.Drawing.Color.Cornsilk;
            this.textBox62.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox62.Location = new System.Drawing.Point(67, 258);
            this.textBox62.Name = "textBox62";
            this.textBox62.ReadOnly = true;
            this.textBox62.Size = new System.Drawing.Size(40, 22);
            this.textBox62.TabIndex = 100;
            this.textBox62.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.textBox62.Visible = false;
            // 
            // textBox63
            // 
            this.textBox63.BackColor = System.Drawing.Color.Cornsilk;
            this.textBox63.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox63.Location = new System.Drawing.Point(122, 258);
            this.textBox63.Name = "textBox63";
            this.textBox63.ReadOnly = true;
            this.textBox63.Size = new System.Drawing.Size(40, 22);
            this.textBox63.TabIndex = 101;
            this.textBox63.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.textBox63.Visible = false;
            // 
            // textBox64
            // 
            this.textBox64.BackColor = System.Drawing.Color.Cornsilk;
            this.textBox64.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox64.Location = new System.Drawing.Point(177, 258);
            this.textBox64.Name = "textBox64";
            this.textBox64.ReadOnly = true;
            this.textBox64.Size = new System.Drawing.Size(40, 22);
            this.textBox64.TabIndex = 102;
            this.textBox64.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.textBox64.Visible = false;
            // 
            // textBox65
            // 
            this.textBox65.BackColor = System.Drawing.Color.Cornsilk;
            this.textBox65.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox65.Location = new System.Drawing.Point(232, 258);
            this.textBox65.Name = "textBox65";
            this.textBox65.ReadOnly = true;
            this.textBox65.Size = new System.Drawing.Size(40, 22);
            this.textBox65.TabIndex = 103;
            this.textBox65.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.textBox65.Visible = false;
            // 
            // textBox66
            // 
            this.textBox66.BackColor = System.Drawing.Color.Cornsilk;
            this.textBox66.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox66.Location = new System.Drawing.Point(287, 258);
            this.textBox66.Name = "textBox66";
            this.textBox66.ReadOnly = true;
            this.textBox66.Size = new System.Drawing.Size(40, 22);
            this.textBox66.TabIndex = 104;
            this.textBox66.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.textBox66.Visible = false;
            // 
            // textBox67
            // 
            this.textBox67.BackColor = System.Drawing.Color.Cornsilk;
            this.textBox67.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox67.Location = new System.Drawing.Point(342, 258);
            this.textBox67.Name = "textBox67";
            this.textBox67.ReadOnly = true;
            this.textBox67.Size = new System.Drawing.Size(40, 22);
            this.textBox67.TabIndex = 105;
            this.textBox67.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.textBox67.Visible = false;
            // 
            // textBox68
            // 
            this.textBox68.BackColor = System.Drawing.Color.Cornsilk;
            this.textBox68.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox68.Location = new System.Drawing.Point(397, 258);
            this.textBox68.Name = "textBox68";
            this.textBox68.ReadOnly = true;
            this.textBox68.Size = new System.Drawing.Size(40, 22);
            this.textBox68.TabIndex = 106;
            this.textBox68.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.textBox68.Visible = false;
            // 
            // textBox69
            // 
            this.textBox69.BackColor = System.Drawing.Color.Cornsilk;
            this.textBox69.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox69.Location = new System.Drawing.Point(452, 258);
            this.textBox69.Name = "textBox69";
            this.textBox69.ReadOnly = true;
            this.textBox69.Size = new System.Drawing.Size(40, 22);
            this.textBox69.TabIndex = 107;
            this.textBox69.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.textBox69.Visible = false;
            // 
            // textBox70
            // 
            this.textBox70.BackColor = System.Drawing.Color.Cornsilk;
            this.textBox70.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox70.Location = new System.Drawing.Point(507, 258);
            this.textBox70.Name = "textBox70";
            this.textBox70.ReadOnly = true;
            this.textBox70.Size = new System.Drawing.Size(40, 22);
            this.textBox70.TabIndex = 108;
            this.textBox70.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.textBox70.Visible = false;
            // 
            // textBox71
            // 
            this.textBox71.BackColor = System.Drawing.Color.Cornsilk;
            this.textBox71.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox71.Location = new System.Drawing.Point(562, 258);
            this.textBox71.Name = "textBox71";
            this.textBox71.ReadOnly = true;
            this.textBox71.Size = new System.Drawing.Size(40, 22);
            this.textBox71.TabIndex = 109;
            this.textBox71.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.textBox71.Visible = false;
            // 
            // textBox72
            // 
            this.textBox72.BackColor = System.Drawing.Color.Cornsilk;
            this.textBox72.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox72.Location = new System.Drawing.Point(617, 258);
            this.textBox72.Name = "textBox72";
            this.textBox72.ReadOnly = true;
            this.textBox72.Size = new System.Drawing.Size(40, 22);
            this.textBox72.TabIndex = 110;
            this.textBox72.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.textBox72.Visible = false;
            // 
            // textBox73
            // 
            this.textBox73.BackColor = System.Drawing.Color.Cornsilk;
            this.textBox73.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox73.Location = new System.Drawing.Point(672, 258);
            this.textBox73.Name = "textBox73";
            this.textBox73.ReadOnly = true;
            this.textBox73.Size = new System.Drawing.Size(40, 22);
            this.textBox73.TabIndex = 111;
            this.textBox73.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.textBox73.Visible = false;
            // 
            // textBox74
            // 
            this.textBox74.BackColor = System.Drawing.Color.Cornsilk;
            this.textBox74.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox74.Location = new System.Drawing.Point(727, 258);
            this.textBox74.Name = "textBox74";
            this.textBox74.ReadOnly = true;
            this.textBox74.Size = new System.Drawing.Size(40, 22);
            this.textBox74.TabIndex = 112;
            this.textBox74.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.textBox74.Visible = false;
            // 
            // textBox75
            // 
            this.textBox75.BackColor = System.Drawing.Color.Cornsilk;
            this.textBox75.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox75.Location = new System.Drawing.Point(783, 258);
            this.textBox75.Name = "textBox75";
            this.textBox75.ReadOnly = true;
            this.textBox75.Size = new System.Drawing.Size(40, 22);
            this.textBox75.TabIndex = 113;
            this.textBox75.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.textBox75.Visible = false;
            // 
            // textBox76
            // 
            this.textBox76.BackColor = System.Drawing.Color.Cornsilk;
            this.textBox76.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox76.Location = new System.Drawing.Point(12, 286);
            this.textBox76.Name = "textBox76";
            this.textBox76.ReadOnly = true;
            this.textBox76.Size = new System.Drawing.Size(40, 22);
            this.textBox76.TabIndex = 114;
            this.textBox76.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.textBox76.Visible = false;
            // 
            // textBox77
            // 
            this.textBox77.BackColor = System.Drawing.Color.Cornsilk;
            this.textBox77.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox77.Location = new System.Drawing.Point(67, 286);
            this.textBox77.Name = "textBox77";
            this.textBox77.ReadOnly = true;
            this.textBox77.Size = new System.Drawing.Size(40, 22);
            this.textBox77.TabIndex = 115;
            this.textBox77.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.textBox77.Visible = false;
            // 
            // textBox78
            // 
            this.textBox78.BackColor = System.Drawing.Color.Cornsilk;
            this.textBox78.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox78.Location = new System.Drawing.Point(122, 286);
            this.textBox78.Name = "textBox78";
            this.textBox78.ReadOnly = true;
            this.textBox78.Size = new System.Drawing.Size(40, 22);
            this.textBox78.TabIndex = 116;
            this.textBox78.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.textBox78.Visible = false;
            // 
            // textBox79
            // 
            this.textBox79.BackColor = System.Drawing.Color.Cornsilk;
            this.textBox79.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox79.Location = new System.Drawing.Point(177, 286);
            this.textBox79.Name = "textBox79";
            this.textBox79.ReadOnly = true;
            this.textBox79.Size = new System.Drawing.Size(40, 22);
            this.textBox79.TabIndex = 117;
            this.textBox79.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.textBox79.Visible = false;
            // 
            // textBox80
            // 
            this.textBox80.BackColor = System.Drawing.Color.Cornsilk;
            this.textBox80.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox80.Location = new System.Drawing.Point(232, 286);
            this.textBox80.Name = "textBox80";
            this.textBox80.ReadOnly = true;
            this.textBox80.Size = new System.Drawing.Size(40, 22);
            this.textBox80.TabIndex = 118;
            this.textBox80.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.textBox80.Visible = false;
            // 
            // textBox81
            // 
            this.textBox81.BackColor = System.Drawing.Color.Cornsilk;
            this.textBox81.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox81.Location = new System.Drawing.Point(287, 286);
            this.textBox81.Name = "textBox81";
            this.textBox81.ReadOnly = true;
            this.textBox81.Size = new System.Drawing.Size(40, 22);
            this.textBox81.TabIndex = 119;
            this.textBox81.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.textBox81.Visible = false;
            // 
            // textBox82
            // 
            this.textBox82.BackColor = System.Drawing.Color.Cornsilk;
            this.textBox82.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox82.Location = new System.Drawing.Point(342, 286);
            this.textBox82.Name = "textBox82";
            this.textBox82.ReadOnly = true;
            this.textBox82.Size = new System.Drawing.Size(40, 22);
            this.textBox82.TabIndex = 120;
            this.textBox82.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.textBox82.Visible = false;
            // 
            // textBox83
            // 
            this.textBox83.BackColor = System.Drawing.Color.Cornsilk;
            this.textBox83.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox83.Location = new System.Drawing.Point(397, 286);
            this.textBox83.Name = "textBox83";
            this.textBox83.ReadOnly = true;
            this.textBox83.Size = new System.Drawing.Size(40, 22);
            this.textBox83.TabIndex = 121;
            this.textBox83.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.textBox83.Visible = false;
            // 
            // textBox84
            // 
            this.textBox84.BackColor = System.Drawing.Color.Cornsilk;
            this.textBox84.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox84.Location = new System.Drawing.Point(452, 286);
            this.textBox84.Name = "textBox84";
            this.textBox84.ReadOnly = true;
            this.textBox84.Size = new System.Drawing.Size(40, 22);
            this.textBox84.TabIndex = 122;
            this.textBox84.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.textBox84.Visible = false;
            // 
            // textBox85
            // 
            this.textBox85.BackColor = System.Drawing.Color.Cornsilk;
            this.textBox85.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox85.Location = new System.Drawing.Point(507, 286);
            this.textBox85.Name = "textBox85";
            this.textBox85.ReadOnly = true;
            this.textBox85.Size = new System.Drawing.Size(40, 22);
            this.textBox85.TabIndex = 123;
            this.textBox85.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.textBox85.Visible = false;
            // 
            // textBox86
            // 
            this.textBox86.BackColor = System.Drawing.Color.Cornsilk;
            this.textBox86.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox86.Location = new System.Drawing.Point(562, 286);
            this.textBox86.Name = "textBox86";
            this.textBox86.ReadOnly = true;
            this.textBox86.Size = new System.Drawing.Size(40, 22);
            this.textBox86.TabIndex = 124;
            this.textBox86.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.textBox86.Visible = false;
            // 
            // textBox87
            // 
            this.textBox87.BackColor = System.Drawing.Color.Cornsilk;
            this.textBox87.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox87.Location = new System.Drawing.Point(617, 286);
            this.textBox87.Name = "textBox87";
            this.textBox87.ReadOnly = true;
            this.textBox87.Size = new System.Drawing.Size(40, 22);
            this.textBox87.TabIndex = 125;
            this.textBox87.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.textBox87.Visible = false;
            // 
            // textBox88
            // 
            this.textBox88.BackColor = System.Drawing.Color.Cornsilk;
            this.textBox88.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox88.Location = new System.Drawing.Point(672, 286);
            this.textBox88.Name = "textBox88";
            this.textBox88.ReadOnly = true;
            this.textBox88.Size = new System.Drawing.Size(40, 22);
            this.textBox88.TabIndex = 126;
            this.textBox88.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.textBox88.Visible = false;
            // 
            // textBox89
            // 
            this.textBox89.BackColor = System.Drawing.Color.Cornsilk;
            this.textBox89.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox89.Location = new System.Drawing.Point(727, 286);
            this.textBox89.Name = "textBox89";
            this.textBox89.ReadOnly = true;
            this.textBox89.Size = new System.Drawing.Size(40, 22);
            this.textBox89.TabIndex = 127;
            this.textBox89.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.textBox89.Visible = false;
            // 
            // textBox90
            // 
            this.textBox90.BackColor = System.Drawing.Color.Cornsilk;
            this.textBox90.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox90.Location = new System.Drawing.Point(783, 286);
            this.textBox90.Name = "textBox90";
            this.textBox90.ReadOnly = true;
            this.textBox90.Size = new System.Drawing.Size(40, 22);
            this.textBox90.TabIndex = 128;
            this.textBox90.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.textBox90.Visible = false;
            // 
            // textBox91
            // 
            this.textBox91.BackColor = System.Drawing.Color.Cornsilk;
            this.textBox91.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox91.Location = new System.Drawing.Point(12, 314);
            this.textBox91.Name = "textBox91";
            this.textBox91.ReadOnly = true;
            this.textBox91.Size = new System.Drawing.Size(40, 22);
            this.textBox91.TabIndex = 129;
            this.textBox91.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.textBox91.Visible = false;
            // 
            // textBox92
            // 
            this.textBox92.BackColor = System.Drawing.Color.Cornsilk;
            this.textBox92.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox92.Location = new System.Drawing.Point(67, 314);
            this.textBox92.Name = "textBox92";
            this.textBox92.ReadOnly = true;
            this.textBox92.Size = new System.Drawing.Size(40, 22);
            this.textBox92.TabIndex = 130;
            this.textBox92.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.textBox92.Visible = false;
            // 
            // textBox93
            // 
            this.textBox93.BackColor = System.Drawing.Color.Cornsilk;
            this.textBox93.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox93.Location = new System.Drawing.Point(122, 314);
            this.textBox93.Name = "textBox93";
            this.textBox93.ReadOnly = true;
            this.textBox93.Size = new System.Drawing.Size(40, 22);
            this.textBox93.TabIndex = 131;
            this.textBox93.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.textBox93.Visible = false;
            // 
            // textBox94
            // 
            this.textBox94.BackColor = System.Drawing.Color.Cornsilk;
            this.textBox94.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox94.Location = new System.Drawing.Point(177, 314);
            this.textBox94.Name = "textBox94";
            this.textBox94.ReadOnly = true;
            this.textBox94.Size = new System.Drawing.Size(40, 22);
            this.textBox94.TabIndex = 132;
            this.textBox94.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.textBox94.Visible = false;
            // 
            // textBox95
            // 
            this.textBox95.BackColor = System.Drawing.Color.Cornsilk;
            this.textBox95.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox95.Location = new System.Drawing.Point(232, 314);
            this.textBox95.Name = "textBox95";
            this.textBox95.ReadOnly = true;
            this.textBox95.Size = new System.Drawing.Size(40, 22);
            this.textBox95.TabIndex = 133;
            this.textBox95.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.textBox95.Visible = false;
            // 
            // textBox96
            // 
            this.textBox96.BackColor = System.Drawing.Color.Cornsilk;
            this.textBox96.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox96.Location = new System.Drawing.Point(287, 314);
            this.textBox96.Name = "textBox96";
            this.textBox96.ReadOnly = true;
            this.textBox96.Size = new System.Drawing.Size(40, 22);
            this.textBox96.TabIndex = 134;
            this.textBox96.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.textBox96.Visible = false;
            // 
            // textBox97
            // 
            this.textBox97.BackColor = System.Drawing.Color.Cornsilk;
            this.textBox97.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox97.Location = new System.Drawing.Point(342, 314);
            this.textBox97.Name = "textBox97";
            this.textBox97.ReadOnly = true;
            this.textBox97.Size = new System.Drawing.Size(40, 22);
            this.textBox97.TabIndex = 135;
            this.textBox97.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.textBox97.Visible = false;
            // 
            // textBox98
            // 
            this.textBox98.BackColor = System.Drawing.Color.Cornsilk;
            this.textBox98.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox98.Location = new System.Drawing.Point(397, 314);
            this.textBox98.Name = "textBox98";
            this.textBox98.ReadOnly = true;
            this.textBox98.Size = new System.Drawing.Size(40, 22);
            this.textBox98.TabIndex = 136;
            this.textBox98.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.textBox98.Visible = false;
            // 
            // textBox99
            // 
            this.textBox99.BackColor = System.Drawing.Color.Cornsilk;
            this.textBox99.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox99.Location = new System.Drawing.Point(452, 314);
            this.textBox99.Name = "textBox99";
            this.textBox99.ReadOnly = true;
            this.textBox99.Size = new System.Drawing.Size(40, 22);
            this.textBox99.TabIndex = 137;
            this.textBox99.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.textBox99.Visible = false;
            // 
            // textBox100
            // 
            this.textBox100.BackColor = System.Drawing.Color.Cornsilk;
            this.textBox100.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox100.Location = new System.Drawing.Point(507, 314);
            this.textBox100.Name = "textBox100";
            this.textBox100.ReadOnly = true;
            this.textBox100.Size = new System.Drawing.Size(40, 22);
            this.textBox100.TabIndex = 138;
            this.textBox100.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.textBox100.Visible = false;
            // 
            // textBox101
            // 
            this.textBox101.BackColor = System.Drawing.Color.Cornsilk;
            this.textBox101.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox101.Location = new System.Drawing.Point(562, 314);
            this.textBox101.Name = "textBox101";
            this.textBox101.ReadOnly = true;
            this.textBox101.Size = new System.Drawing.Size(40, 22);
            this.textBox101.TabIndex = 139;
            this.textBox101.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.textBox101.Visible = false;
            // 
            // textBox102
            // 
            this.textBox102.BackColor = System.Drawing.Color.Cornsilk;
            this.textBox102.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox102.Location = new System.Drawing.Point(617, 314);
            this.textBox102.Name = "textBox102";
            this.textBox102.ReadOnly = true;
            this.textBox102.Size = new System.Drawing.Size(40, 22);
            this.textBox102.TabIndex = 140;
            this.textBox102.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.textBox102.Visible = false;
            // 
            // textBox103
            // 
            this.textBox103.BackColor = System.Drawing.Color.Cornsilk;
            this.textBox103.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox103.Location = new System.Drawing.Point(672, 314);
            this.textBox103.Name = "textBox103";
            this.textBox103.ReadOnly = true;
            this.textBox103.Size = new System.Drawing.Size(40, 22);
            this.textBox103.TabIndex = 141;
            this.textBox103.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.textBox103.Visible = false;
            // 
            // textBox104
            // 
            this.textBox104.BackColor = System.Drawing.Color.Cornsilk;
            this.textBox104.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox104.Location = new System.Drawing.Point(727, 314);
            this.textBox104.Name = "textBox104";
            this.textBox104.ReadOnly = true;
            this.textBox104.Size = new System.Drawing.Size(40, 22);
            this.textBox104.TabIndex = 142;
            this.textBox104.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.textBox104.Visible = false;
            // 
            // textBox105
            // 
            this.textBox105.BackColor = System.Drawing.Color.Cornsilk;
            this.textBox105.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox105.Location = new System.Drawing.Point(783, 314);
            this.textBox105.Name = "textBox105";
            this.textBox105.ReadOnly = true;
            this.textBox105.Size = new System.Drawing.Size(40, 22);
            this.textBox105.TabIndex = 143;
            this.textBox105.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.textBox105.Visible = false;
            // 
            // textBox106
            // 
            this.textBox106.BackColor = System.Drawing.Color.Cornsilk;
            this.textBox106.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox106.Location = new System.Drawing.Point(12, 342);
            this.textBox106.Name = "textBox106";
            this.textBox106.ReadOnly = true;
            this.textBox106.Size = new System.Drawing.Size(40, 22);
            this.textBox106.TabIndex = 144;
            this.textBox106.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.textBox106.Visible = false;
            // 
            // textBox107
            // 
            this.textBox107.BackColor = System.Drawing.Color.Cornsilk;
            this.textBox107.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox107.Location = new System.Drawing.Point(67, 342);
            this.textBox107.Name = "textBox107";
            this.textBox107.ReadOnly = true;
            this.textBox107.Size = new System.Drawing.Size(40, 22);
            this.textBox107.TabIndex = 145;
            this.textBox107.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.textBox107.Visible = false;
            // 
            // textBox108
            // 
            this.textBox108.BackColor = System.Drawing.Color.Cornsilk;
            this.textBox108.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox108.Location = new System.Drawing.Point(122, 342);
            this.textBox108.Name = "textBox108";
            this.textBox108.ReadOnly = true;
            this.textBox108.Size = new System.Drawing.Size(40, 22);
            this.textBox108.TabIndex = 146;
            this.textBox108.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.textBox108.Visible = false;
            // 
            // textBox109
            // 
            this.textBox109.BackColor = System.Drawing.Color.Cornsilk;
            this.textBox109.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox109.Location = new System.Drawing.Point(177, 342);
            this.textBox109.Name = "textBox109";
            this.textBox109.ReadOnly = true;
            this.textBox109.Size = new System.Drawing.Size(40, 22);
            this.textBox109.TabIndex = 147;
            this.textBox109.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.textBox109.Visible = false;
            // 
            // textBox110
            // 
            this.textBox110.BackColor = System.Drawing.Color.Cornsilk;
            this.textBox110.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox110.Location = new System.Drawing.Point(232, 342);
            this.textBox110.Name = "textBox110";
            this.textBox110.ReadOnly = true;
            this.textBox110.Size = new System.Drawing.Size(40, 22);
            this.textBox110.TabIndex = 148;
            this.textBox110.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.textBox110.Visible = false;
            // 
            // textBox111
            // 
            this.textBox111.BackColor = System.Drawing.Color.Cornsilk;
            this.textBox111.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox111.Location = new System.Drawing.Point(287, 342);
            this.textBox111.Name = "textBox111";
            this.textBox111.ReadOnly = true;
            this.textBox111.Size = new System.Drawing.Size(40, 22);
            this.textBox111.TabIndex = 149;
            this.textBox111.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.textBox111.Visible = false;
            // 
            // textBox112
            // 
            this.textBox112.BackColor = System.Drawing.Color.Cornsilk;
            this.textBox112.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox112.Location = new System.Drawing.Point(342, 342);
            this.textBox112.Name = "textBox112";
            this.textBox112.ReadOnly = true;
            this.textBox112.Size = new System.Drawing.Size(40, 22);
            this.textBox112.TabIndex = 150;
            this.textBox112.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.textBox112.Visible = false;
            // 
            // textBox113
            // 
            this.textBox113.BackColor = System.Drawing.Color.Cornsilk;
            this.textBox113.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox113.Location = new System.Drawing.Point(397, 342);
            this.textBox113.Name = "textBox113";
            this.textBox113.ReadOnly = true;
            this.textBox113.Size = new System.Drawing.Size(40, 22);
            this.textBox113.TabIndex = 151;
            this.textBox113.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.textBox113.Visible = false;
            // 
            // textBox114
            // 
            this.textBox114.BackColor = System.Drawing.Color.Cornsilk;
            this.textBox114.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox114.Location = new System.Drawing.Point(452, 342);
            this.textBox114.Name = "textBox114";
            this.textBox114.ReadOnly = true;
            this.textBox114.Size = new System.Drawing.Size(40, 22);
            this.textBox114.TabIndex = 152;
            this.textBox114.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.textBox114.Visible = false;
            // 
            // textBox115
            // 
            this.textBox115.BackColor = System.Drawing.Color.Cornsilk;
            this.textBox115.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox115.Location = new System.Drawing.Point(507, 342);
            this.textBox115.Name = "textBox115";
            this.textBox115.ReadOnly = true;
            this.textBox115.Size = new System.Drawing.Size(40, 22);
            this.textBox115.TabIndex = 153;
            this.textBox115.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.textBox115.Visible = false;
            // 
            // textBox116
            // 
            this.textBox116.BackColor = System.Drawing.Color.Cornsilk;
            this.textBox116.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox116.Location = new System.Drawing.Point(562, 342);
            this.textBox116.Name = "textBox116";
            this.textBox116.ReadOnly = true;
            this.textBox116.Size = new System.Drawing.Size(40, 22);
            this.textBox116.TabIndex = 154;
            this.textBox116.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.textBox116.Visible = false;
            // 
            // textBox117
            // 
            this.textBox117.BackColor = System.Drawing.Color.Cornsilk;
            this.textBox117.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox117.Location = new System.Drawing.Point(617, 342);
            this.textBox117.Name = "textBox117";
            this.textBox117.ReadOnly = true;
            this.textBox117.Size = new System.Drawing.Size(40, 22);
            this.textBox117.TabIndex = 155;
            this.textBox117.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.textBox117.Visible = false;
            // 
            // textBox118
            // 
            this.textBox118.BackColor = System.Drawing.Color.Cornsilk;
            this.textBox118.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox118.Location = new System.Drawing.Point(672, 342);
            this.textBox118.Name = "textBox118";
            this.textBox118.ReadOnly = true;
            this.textBox118.Size = new System.Drawing.Size(40, 22);
            this.textBox118.TabIndex = 156;
            this.textBox118.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.textBox118.Visible = false;
            // 
            // textBox119
            // 
            this.textBox119.BackColor = System.Drawing.Color.Cornsilk;
            this.textBox119.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox119.Location = new System.Drawing.Point(727, 342);
            this.textBox119.Name = "textBox119";
            this.textBox119.ReadOnly = true;
            this.textBox119.Size = new System.Drawing.Size(40, 22);
            this.textBox119.TabIndex = 157;
            this.textBox119.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.textBox119.Visible = false;
            // 
            // textBox120
            // 
            this.textBox120.BackColor = System.Drawing.Color.Cornsilk;
            this.textBox120.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox120.Location = new System.Drawing.Point(783, 342);
            this.textBox120.Name = "textBox120";
            this.textBox120.ReadOnly = true;
            this.textBox120.Size = new System.Drawing.Size(40, 22);
            this.textBox120.TabIndex = 158;
            this.textBox120.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.textBox120.Visible = false;
            // 
            // textBox121
            // 
            this.textBox121.BackColor = System.Drawing.Color.Cornsilk;
            this.textBox121.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox121.Location = new System.Drawing.Point(12, 370);
            this.textBox121.Name = "textBox121";
            this.textBox121.ReadOnly = true;
            this.textBox121.Size = new System.Drawing.Size(40, 22);
            this.textBox121.TabIndex = 159;
            this.textBox121.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.textBox121.Visible = false;
            // 
            // textBox122
            // 
            this.textBox122.BackColor = System.Drawing.Color.Cornsilk;
            this.textBox122.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox122.Location = new System.Drawing.Point(67, 370);
            this.textBox122.Name = "textBox122";
            this.textBox122.ReadOnly = true;
            this.textBox122.Size = new System.Drawing.Size(40, 22);
            this.textBox122.TabIndex = 160;
            this.textBox122.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.textBox122.Visible = false;
            // 
            // textBox123
            // 
            this.textBox123.BackColor = System.Drawing.Color.Cornsilk;
            this.textBox123.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox123.Location = new System.Drawing.Point(177, 370);
            this.textBox123.Name = "textBox123";
            this.textBox123.ReadOnly = true;
            this.textBox123.Size = new System.Drawing.Size(40, 22);
            this.textBox123.TabIndex = 161;
            this.textBox123.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.textBox123.Visible = false;
            // 
            // textBox124
            // 
            this.textBox124.BackColor = System.Drawing.Color.Cornsilk;
            this.textBox124.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox124.Location = new System.Drawing.Point(122, 370);
            this.textBox124.Name = "textBox124";
            this.textBox124.ReadOnly = true;
            this.textBox124.Size = new System.Drawing.Size(40, 22);
            this.textBox124.TabIndex = 161;
            this.textBox124.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.textBox124.Visible = false;
            // 
            // textBox125
            // 
            this.textBox125.BackColor = System.Drawing.Color.Cornsilk;
            this.textBox125.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox125.Location = new System.Drawing.Point(232, 370);
            this.textBox125.Name = "textBox125";
            this.textBox125.ReadOnly = true;
            this.textBox125.Size = new System.Drawing.Size(40, 22);
            this.textBox125.TabIndex = 162;
            this.textBox125.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.textBox125.Visible = false;
            // 
            // textBox126
            // 
            this.textBox126.BackColor = System.Drawing.Color.Cornsilk;
            this.textBox126.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox126.Location = new System.Drawing.Point(287, 370);
            this.textBox126.Name = "textBox126";
            this.textBox126.ReadOnly = true;
            this.textBox126.Size = new System.Drawing.Size(40, 22);
            this.textBox126.TabIndex = 163;
            this.textBox126.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.textBox126.Visible = false;
            // 
            // textBox127
            // 
            this.textBox127.BackColor = System.Drawing.Color.Cornsilk;
            this.textBox127.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox127.Location = new System.Drawing.Point(342, 370);
            this.textBox127.Name = "textBox127";
            this.textBox127.ReadOnly = true;
            this.textBox127.Size = new System.Drawing.Size(40, 22);
            this.textBox127.TabIndex = 164;
            this.textBox127.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.textBox127.Visible = false;
            // 
            // textBox128
            // 
            this.textBox128.BackColor = System.Drawing.Color.Cornsilk;
            this.textBox128.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox128.Location = new System.Drawing.Point(397, 370);
            this.textBox128.Name = "textBox128";
            this.textBox128.ReadOnly = true;
            this.textBox128.Size = new System.Drawing.Size(40, 22);
            this.textBox128.TabIndex = 165;
            this.textBox128.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.textBox128.Visible = false;
            // 
            // textBox129
            // 
            this.textBox129.BackColor = System.Drawing.Color.Cornsilk;
            this.textBox129.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox129.Location = new System.Drawing.Point(452, 370);
            this.textBox129.Name = "textBox129";
            this.textBox129.ReadOnly = true;
            this.textBox129.Size = new System.Drawing.Size(40, 22);
            this.textBox129.TabIndex = 166;
            this.textBox129.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.textBox129.Visible = false;
            // 
            // textBox130
            // 
            this.textBox130.BackColor = System.Drawing.Color.Cornsilk;
            this.textBox130.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox130.Location = new System.Drawing.Point(507, 370);
            this.textBox130.Name = "textBox130";
            this.textBox130.ReadOnly = true;
            this.textBox130.Size = new System.Drawing.Size(40, 22);
            this.textBox130.TabIndex = 167;
            this.textBox130.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.textBox130.Visible = false;
            // 
            // textBox131
            // 
            this.textBox131.BackColor = System.Drawing.Color.Cornsilk;
            this.textBox131.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox131.Location = new System.Drawing.Point(562, 370);
            this.textBox131.Name = "textBox131";
            this.textBox131.ReadOnly = true;
            this.textBox131.Size = new System.Drawing.Size(40, 22);
            this.textBox131.TabIndex = 168;
            this.textBox131.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.textBox131.Visible = false;
            // 
            // textBox132
            // 
            this.textBox132.BackColor = System.Drawing.Color.Cornsilk;
            this.textBox132.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox132.Location = new System.Drawing.Point(617, 370);
            this.textBox132.Name = "textBox132";
            this.textBox132.ReadOnly = true;
            this.textBox132.Size = new System.Drawing.Size(40, 22);
            this.textBox132.TabIndex = 169;
            this.textBox132.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.textBox132.Visible = false;
            // 
            // textBox133
            // 
            this.textBox133.BackColor = System.Drawing.Color.Cornsilk;
            this.textBox133.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox133.Location = new System.Drawing.Point(672, 370);
            this.textBox133.Name = "textBox133";
            this.textBox133.ReadOnly = true;
            this.textBox133.Size = new System.Drawing.Size(40, 22);
            this.textBox133.TabIndex = 170;
            this.textBox133.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.textBox133.Visible = false;
            // 
            // textBox134
            // 
            this.textBox134.BackColor = System.Drawing.Color.Cornsilk;
            this.textBox134.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox134.Location = new System.Drawing.Point(727, 370);
            this.textBox134.Name = "textBox134";
            this.textBox134.ReadOnly = true;
            this.textBox134.Size = new System.Drawing.Size(40, 22);
            this.textBox134.TabIndex = 171;
            this.textBox134.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.textBox134.Visible = false;
            // 
            // textBox135
            // 
            this.textBox135.BackColor = System.Drawing.Color.Cornsilk;
            this.textBox135.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox135.Location = new System.Drawing.Point(783, 370);
            this.textBox135.Name = "textBox135";
            this.textBox135.ReadOnly = true;
            this.textBox135.Size = new System.Drawing.Size(40, 22);
            this.textBox135.TabIndex = 172;
            this.textBox135.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.textBox135.Visible = false;
            // 
            // textBox136
            // 
            this.textBox136.BackColor = System.Drawing.Color.Cornsilk;
            this.textBox136.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox136.Location = new System.Drawing.Point(12, 398);
            this.textBox136.Name = "textBox136";
            this.textBox136.ReadOnly = true;
            this.textBox136.Size = new System.Drawing.Size(40, 22);
            this.textBox136.TabIndex = 173;
            this.textBox136.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.textBox136.Visible = false;
            // 
            // textBox137
            // 
            this.textBox137.BackColor = System.Drawing.Color.Cornsilk;
            this.textBox137.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox137.Location = new System.Drawing.Point(67, 398);
            this.textBox137.Name = "textBox137";
            this.textBox137.ReadOnly = true;
            this.textBox137.Size = new System.Drawing.Size(40, 22);
            this.textBox137.TabIndex = 174;
            this.textBox137.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.textBox137.Visible = false;
            // 
            // textBox138
            // 
            this.textBox138.BackColor = System.Drawing.Color.Cornsilk;
            this.textBox138.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox138.Location = new System.Drawing.Point(122, 398);
            this.textBox138.Name = "textBox138";
            this.textBox138.ReadOnly = true;
            this.textBox138.Size = new System.Drawing.Size(40, 22);
            this.textBox138.TabIndex = 175;
            this.textBox138.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.textBox138.Visible = false;
            // 
            // textBox139
            // 
            this.textBox139.BackColor = System.Drawing.Color.Cornsilk;
            this.textBox139.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox139.Location = new System.Drawing.Point(177, 398);
            this.textBox139.Name = "textBox139";
            this.textBox139.ReadOnly = true;
            this.textBox139.Size = new System.Drawing.Size(40, 22);
            this.textBox139.TabIndex = 176;
            this.textBox139.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.textBox139.Visible = false;
            // 
            // textBox140
            // 
            this.textBox140.BackColor = System.Drawing.Color.Cornsilk;
            this.textBox140.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox140.Location = new System.Drawing.Point(232, 398);
            this.textBox140.Name = "textBox140";
            this.textBox140.ReadOnly = true;
            this.textBox140.Size = new System.Drawing.Size(40, 22);
            this.textBox140.TabIndex = 177;
            this.textBox140.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.textBox140.Visible = false;
            // 
            // textBox141
            // 
            this.textBox141.BackColor = System.Drawing.Color.Cornsilk;
            this.textBox141.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox141.Location = new System.Drawing.Point(287, 398);
            this.textBox141.Name = "textBox141";
            this.textBox141.ReadOnly = true;
            this.textBox141.Size = new System.Drawing.Size(40, 22);
            this.textBox141.TabIndex = 178;
            this.textBox141.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.textBox141.Visible = false;
            // 
            // textBox142
            // 
            this.textBox142.BackColor = System.Drawing.Color.Cornsilk;
            this.textBox142.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox142.Location = new System.Drawing.Point(342, 398);
            this.textBox142.Name = "textBox142";
            this.textBox142.ReadOnly = true;
            this.textBox142.Size = new System.Drawing.Size(40, 22);
            this.textBox142.TabIndex = 179;
            this.textBox142.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.textBox142.Visible = false;
            // 
            // textBox143
            // 
            this.textBox143.BackColor = System.Drawing.Color.Cornsilk;
            this.textBox143.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox143.Location = new System.Drawing.Point(397, 398);
            this.textBox143.Name = "textBox143";
            this.textBox143.ReadOnly = true;
            this.textBox143.Size = new System.Drawing.Size(40, 22);
            this.textBox143.TabIndex = 180;
            this.textBox143.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.textBox143.Visible = false;
            // 
            // textBox144
            // 
            this.textBox144.BackColor = System.Drawing.Color.Cornsilk;
            this.textBox144.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox144.Location = new System.Drawing.Point(452, 398);
            this.textBox144.Name = "textBox144";
            this.textBox144.ReadOnly = true;
            this.textBox144.Size = new System.Drawing.Size(40, 22);
            this.textBox144.TabIndex = 181;
            this.textBox144.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.textBox144.Visible = false;
            // 
            // textBox145
            // 
            this.textBox145.BackColor = System.Drawing.Color.Cornsilk;
            this.textBox145.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox145.Location = new System.Drawing.Point(507, 398);
            this.textBox145.Name = "textBox145";
            this.textBox145.ReadOnly = true;
            this.textBox145.Size = new System.Drawing.Size(40, 22);
            this.textBox145.TabIndex = 182;
            this.textBox145.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.textBox145.Visible = false;
            // 
            // textBox146
            // 
            this.textBox146.BackColor = System.Drawing.Color.Cornsilk;
            this.textBox146.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox146.Location = new System.Drawing.Point(562, 398);
            this.textBox146.Name = "textBox146";
            this.textBox146.ReadOnly = true;
            this.textBox146.Size = new System.Drawing.Size(40, 22);
            this.textBox146.TabIndex = 183;
            this.textBox146.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.textBox146.Visible = false;
            // 
            // textBox147
            // 
            this.textBox147.BackColor = System.Drawing.Color.Cornsilk;
            this.textBox147.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox147.Location = new System.Drawing.Point(617, 398);
            this.textBox147.Name = "textBox147";
            this.textBox147.ReadOnly = true;
            this.textBox147.Size = new System.Drawing.Size(40, 22);
            this.textBox147.TabIndex = 184;
            this.textBox147.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.textBox147.Visible = false;
            // 
            // textBox148
            // 
            this.textBox148.BackColor = System.Drawing.Color.Cornsilk;
            this.textBox148.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox148.Location = new System.Drawing.Point(672, 398);
            this.textBox148.Name = "textBox148";
            this.textBox148.ReadOnly = true;
            this.textBox148.Size = new System.Drawing.Size(40, 22);
            this.textBox148.TabIndex = 185;
            this.textBox148.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.textBox148.Visible = false;
            // 
            // textBox149
            // 
            this.textBox149.BackColor = System.Drawing.Color.Cornsilk;
            this.textBox149.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox149.Location = new System.Drawing.Point(727, 398);
            this.textBox149.Name = "textBox149";
            this.textBox149.ReadOnly = true;
            this.textBox149.Size = new System.Drawing.Size(40, 22);
            this.textBox149.TabIndex = 186;
            this.textBox149.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.textBox149.Visible = false;
            // 
            // textBox150
            // 
            this.textBox150.BackColor = System.Drawing.Color.Cornsilk;
            this.textBox150.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox150.Location = new System.Drawing.Point(783, 398);
            this.textBox150.Name = "textBox150";
            this.textBox150.ReadOnly = true;
            this.textBox150.Size = new System.Drawing.Size(40, 22);
            this.textBox150.TabIndex = 187;
            this.textBox150.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.textBox150.Visible = false;
            // 
            // textBox151
            // 
            this.textBox151.BackColor = System.Drawing.Color.Cornsilk;
            this.textBox151.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox151.Location = new System.Drawing.Point(12, 426);
            this.textBox151.Name = "textBox151";
            this.textBox151.ReadOnly = true;
            this.textBox151.Size = new System.Drawing.Size(40, 22);
            this.textBox151.TabIndex = 188;
            this.textBox151.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.textBox151.Visible = false;
            // 
            // textBox152
            // 
            this.textBox152.BackColor = System.Drawing.Color.Cornsilk;
            this.textBox152.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox152.Location = new System.Drawing.Point(67, 426);
            this.textBox152.Name = "textBox152";
            this.textBox152.ReadOnly = true;
            this.textBox152.Size = new System.Drawing.Size(40, 22);
            this.textBox152.TabIndex = 189;
            this.textBox152.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.textBox152.Visible = false;
            // 
            // textBox153
            // 
            this.textBox153.BackColor = System.Drawing.Color.Cornsilk;
            this.textBox153.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox153.Location = new System.Drawing.Point(122, 426);
            this.textBox153.Name = "textBox153";
            this.textBox153.ReadOnly = true;
            this.textBox153.Size = new System.Drawing.Size(40, 22);
            this.textBox153.TabIndex = 190;
            this.textBox153.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.textBox153.Visible = false;
            // 
            // textBox154
            // 
            this.textBox154.BackColor = System.Drawing.Color.Cornsilk;
            this.textBox154.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox154.Location = new System.Drawing.Point(177, 426);
            this.textBox154.Name = "textBox154";
            this.textBox154.ReadOnly = true;
            this.textBox154.Size = new System.Drawing.Size(40, 22);
            this.textBox154.TabIndex = 191;
            this.textBox154.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.textBox154.Visible = false;
            // 
            // textBox155
            // 
            this.textBox155.BackColor = System.Drawing.Color.Cornsilk;
            this.textBox155.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox155.Location = new System.Drawing.Point(287, 426);
            this.textBox155.Name = "textBox155";
            this.textBox155.ReadOnly = true;
            this.textBox155.Size = new System.Drawing.Size(40, 22);
            this.textBox155.TabIndex = 192;
            this.textBox155.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.textBox155.Visible = false;
            // 
            // textBox156
            // 
            this.textBox156.BackColor = System.Drawing.Color.Cornsilk;
            this.textBox156.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox156.Location = new System.Drawing.Point(232, 426);
            this.textBox156.Name = "textBox156";
            this.textBox156.ReadOnly = true;
            this.textBox156.Size = new System.Drawing.Size(40, 22);
            this.textBox156.TabIndex = 192;
            this.textBox156.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.textBox156.Visible = false;
            // 
            // textBox157
            // 
            this.textBox157.BackColor = System.Drawing.Color.Cornsilk;
            this.textBox157.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox157.Location = new System.Drawing.Point(342, 426);
            this.textBox157.Name = "textBox157";
            this.textBox157.ReadOnly = true;
            this.textBox157.Size = new System.Drawing.Size(40, 22);
            this.textBox157.TabIndex = 193;
            this.textBox157.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.textBox157.Visible = false;
            // 
            // textBox158
            // 
            this.textBox158.BackColor = System.Drawing.Color.Cornsilk;
            this.textBox158.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox158.Location = new System.Drawing.Point(397, 426);
            this.textBox158.Name = "textBox158";
            this.textBox158.ReadOnly = true;
            this.textBox158.Size = new System.Drawing.Size(40, 22);
            this.textBox158.TabIndex = 194;
            this.textBox158.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.textBox158.Visible = false;
            // 
            // textBox159
            // 
            this.textBox159.BackColor = System.Drawing.Color.Cornsilk;
            this.textBox159.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox159.Location = new System.Drawing.Point(452, 426);
            this.textBox159.Name = "textBox159";
            this.textBox159.ReadOnly = true;
            this.textBox159.Size = new System.Drawing.Size(40, 22);
            this.textBox159.TabIndex = 195;
            this.textBox159.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.textBox159.Visible = false;
            // 
            // textBox160
            // 
            this.textBox160.BackColor = System.Drawing.Color.Cornsilk;
            this.textBox160.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox160.Location = new System.Drawing.Point(507, 426);
            this.textBox160.Name = "textBox160";
            this.textBox160.ReadOnly = true;
            this.textBox160.Size = new System.Drawing.Size(40, 22);
            this.textBox160.TabIndex = 196;
            this.textBox160.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.textBox160.Visible = false;
            // 
            // textBox161
            // 
            this.textBox161.BackColor = System.Drawing.Color.Cornsilk;
            this.textBox161.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox161.Location = new System.Drawing.Point(562, 426);
            this.textBox161.Name = "textBox161";
            this.textBox161.ReadOnly = true;
            this.textBox161.Size = new System.Drawing.Size(40, 22);
            this.textBox161.TabIndex = 197;
            this.textBox161.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.textBox161.Visible = false;
            // 
            // textBox162
            // 
            this.textBox162.BackColor = System.Drawing.Color.Cornsilk;
            this.textBox162.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox162.Location = new System.Drawing.Point(617, 426);
            this.textBox162.Name = "textBox162";
            this.textBox162.ReadOnly = true;
            this.textBox162.Size = new System.Drawing.Size(40, 22);
            this.textBox162.TabIndex = 198;
            this.textBox162.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.textBox162.Visible = false;
            // 
            // textBox163
            // 
            this.textBox163.BackColor = System.Drawing.Color.Cornsilk;
            this.textBox163.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox163.Location = new System.Drawing.Point(672, 426);
            this.textBox163.Name = "textBox163";
            this.textBox163.ReadOnly = true;
            this.textBox163.Size = new System.Drawing.Size(40, 22);
            this.textBox163.TabIndex = 199;
            this.textBox163.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.textBox163.Visible = false;
            // 
            // textBox164
            // 
            this.textBox164.BackColor = System.Drawing.Color.Cornsilk;
            this.textBox164.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox164.Location = new System.Drawing.Point(727, 426);
            this.textBox164.Name = "textBox164";
            this.textBox164.ReadOnly = true;
            this.textBox164.Size = new System.Drawing.Size(40, 22);
            this.textBox164.TabIndex = 200;
            this.textBox164.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.textBox164.Visible = false;
            // 
            // textBox165
            // 
            this.textBox165.BackColor = System.Drawing.Color.Cornsilk;
            this.textBox165.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox165.Location = new System.Drawing.Point(783, 426);
            this.textBox165.Name = "textBox165";
            this.textBox165.ReadOnly = true;
            this.textBox165.Size = new System.Drawing.Size(40, 22);
            this.textBox165.TabIndex = 201;
            this.textBox165.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.textBox165.Visible = false;
            // 
            // textBox166
            // 
            this.textBox166.BackColor = System.Drawing.Color.Cornsilk;
            this.textBox166.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox166.Location = new System.Drawing.Point(12, 454);
            this.textBox166.Name = "textBox166";
            this.textBox166.ReadOnly = true;
            this.textBox166.Size = new System.Drawing.Size(40, 22);
            this.textBox166.TabIndex = 202;
            this.textBox166.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.textBox166.Visible = false;
            // 
            // textBox167
            // 
            this.textBox167.BackColor = System.Drawing.Color.Cornsilk;
            this.textBox167.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox167.Location = new System.Drawing.Point(67, 454);
            this.textBox167.Name = "textBox167";
            this.textBox167.ReadOnly = true;
            this.textBox167.Size = new System.Drawing.Size(40, 22);
            this.textBox167.TabIndex = 203;
            this.textBox167.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.textBox167.Visible = false;
            // 
            // textBox168
            // 
            this.textBox168.BackColor = System.Drawing.Color.Cornsilk;
            this.textBox168.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox168.Location = new System.Drawing.Point(122, 454);
            this.textBox168.Name = "textBox168";
            this.textBox168.ReadOnly = true;
            this.textBox168.Size = new System.Drawing.Size(40, 22);
            this.textBox168.TabIndex = 204;
            this.textBox168.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.textBox168.Visible = false;
            // 
            // textBox169
            // 
            this.textBox169.BackColor = System.Drawing.Color.Cornsilk;
            this.textBox169.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox169.Location = new System.Drawing.Point(177, 454);
            this.textBox169.Name = "textBox169";
            this.textBox169.ReadOnly = true;
            this.textBox169.Size = new System.Drawing.Size(40, 22);
            this.textBox169.TabIndex = 205;
            this.textBox169.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.textBox169.Visible = false;
            // 
            // textBox170
            // 
            this.textBox170.BackColor = System.Drawing.Color.Cornsilk;
            this.textBox170.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox170.Location = new System.Drawing.Point(232, 454);
            this.textBox170.Name = "textBox170";
            this.textBox170.ReadOnly = true;
            this.textBox170.Size = new System.Drawing.Size(40, 22);
            this.textBox170.TabIndex = 206;
            this.textBox170.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.textBox170.Visible = false;
            // 
            // textBox171
            // 
            this.textBox171.BackColor = System.Drawing.Color.Cornsilk;
            this.textBox171.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox171.Location = new System.Drawing.Point(287, 454);
            this.textBox171.Name = "textBox171";
            this.textBox171.ReadOnly = true;
            this.textBox171.Size = new System.Drawing.Size(40, 22);
            this.textBox171.TabIndex = 207;
            this.textBox171.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.textBox171.Visible = false;
            // 
            // textBox172
            // 
            this.textBox172.BackColor = System.Drawing.Color.Cornsilk;
            this.textBox172.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox172.Location = new System.Drawing.Point(342, 454);
            this.textBox172.Name = "textBox172";
            this.textBox172.ReadOnly = true;
            this.textBox172.Size = new System.Drawing.Size(40, 22);
            this.textBox172.TabIndex = 208;
            this.textBox172.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.textBox172.Visible = false;
            // 
            // textBox173
            // 
            this.textBox173.BackColor = System.Drawing.Color.Cornsilk;
            this.textBox173.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox173.Location = new System.Drawing.Point(397, 454);
            this.textBox173.Name = "textBox173";
            this.textBox173.ReadOnly = true;
            this.textBox173.Size = new System.Drawing.Size(40, 22);
            this.textBox173.TabIndex = 209;
            this.textBox173.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.textBox173.Visible = false;
            // 
            // textBox174
            // 
            this.textBox174.BackColor = System.Drawing.Color.Cornsilk;
            this.textBox174.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox174.Location = new System.Drawing.Point(452, 454);
            this.textBox174.Name = "textBox174";
            this.textBox174.ReadOnly = true;
            this.textBox174.Size = new System.Drawing.Size(40, 22);
            this.textBox174.TabIndex = 210;
            this.textBox174.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.textBox174.Visible = false;
            // 
            // textBox175
            // 
            this.textBox175.BackColor = System.Drawing.Color.Cornsilk;
            this.textBox175.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox175.Location = new System.Drawing.Point(507, 454);
            this.textBox175.Name = "textBox175";
            this.textBox175.ReadOnly = true;
            this.textBox175.Size = new System.Drawing.Size(40, 22);
            this.textBox175.TabIndex = 211;
            this.textBox175.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.textBox175.Visible = false;
            // 
            // textBox176
            // 
            this.textBox176.BackColor = System.Drawing.Color.Cornsilk;
            this.textBox176.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox176.Location = new System.Drawing.Point(562, 454);
            this.textBox176.Name = "textBox176";
            this.textBox176.ReadOnly = true;
            this.textBox176.Size = new System.Drawing.Size(40, 22);
            this.textBox176.TabIndex = 212;
            this.textBox176.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.textBox176.Visible = false;
            // 
            // textBox177
            // 
            this.textBox177.BackColor = System.Drawing.Color.Cornsilk;
            this.textBox177.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox177.Location = new System.Drawing.Point(617, 454);
            this.textBox177.Name = "textBox177";
            this.textBox177.ReadOnly = true;
            this.textBox177.Size = new System.Drawing.Size(40, 22);
            this.textBox177.TabIndex = 213;
            this.textBox177.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.textBox177.Visible = false;
            // 
            // textBox178
            // 
            this.textBox178.BackColor = System.Drawing.Color.Cornsilk;
            this.textBox178.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox178.Location = new System.Drawing.Point(672, 454);
            this.textBox178.Name = "textBox178";
            this.textBox178.ReadOnly = true;
            this.textBox178.Size = new System.Drawing.Size(40, 22);
            this.textBox178.TabIndex = 214;
            this.textBox178.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.textBox178.Visible = false;
            // 
            // textBox179
            // 
            this.textBox179.BackColor = System.Drawing.Color.Cornsilk;
            this.textBox179.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox179.Location = new System.Drawing.Point(727, 454);
            this.textBox179.Name = "textBox179";
            this.textBox179.ReadOnly = true;
            this.textBox179.Size = new System.Drawing.Size(40, 22);
            this.textBox179.TabIndex = 215;
            this.textBox179.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.textBox179.Visible = false;
            // 
            // textBox180
            // 
            this.textBox180.BackColor = System.Drawing.Color.Cornsilk;
            this.textBox180.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox180.Location = new System.Drawing.Point(783, 454);
            this.textBox180.Name = "textBox180";
            this.textBox180.ReadOnly = true;
            this.textBox180.Size = new System.Drawing.Size(40, 22);
            this.textBox180.TabIndex = 216;
            this.textBox180.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.textBox180.Visible = false;
            // 
            // textBox181
            // 
            this.textBox181.BackColor = System.Drawing.Color.Cornsilk;
            this.textBox181.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox181.Location = new System.Drawing.Point(12, 482);
            this.textBox181.Name = "textBox181";
            this.textBox181.ReadOnly = true;
            this.textBox181.Size = new System.Drawing.Size(40, 22);
            this.textBox181.TabIndex = 217;
            this.textBox181.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.textBox181.Visible = false;
            // 
            // textBox182
            // 
            this.textBox182.BackColor = System.Drawing.Color.Cornsilk;
            this.textBox182.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox182.Location = new System.Drawing.Point(67, 482);
            this.textBox182.Name = "textBox182";
            this.textBox182.ReadOnly = true;
            this.textBox182.Size = new System.Drawing.Size(40, 22);
            this.textBox182.TabIndex = 218;
            this.textBox182.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.textBox182.Visible = false;
            // 
            // textBox183
            // 
            this.textBox183.BackColor = System.Drawing.Color.Cornsilk;
            this.textBox183.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox183.Location = new System.Drawing.Point(122, 482);
            this.textBox183.Name = "textBox183";
            this.textBox183.ReadOnly = true;
            this.textBox183.Size = new System.Drawing.Size(40, 22);
            this.textBox183.TabIndex = 219;
            this.textBox183.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.textBox183.Visible = false;
            // 
            // textBox184
            // 
            this.textBox184.BackColor = System.Drawing.Color.Cornsilk;
            this.textBox184.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox184.Location = new System.Drawing.Point(177, 482);
            this.textBox184.Name = "textBox184";
            this.textBox184.ReadOnly = true;
            this.textBox184.Size = new System.Drawing.Size(40, 22);
            this.textBox184.TabIndex = 220;
            this.textBox184.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.textBox184.Visible = false;
            // 
            // textBox185
            // 
            this.textBox185.BackColor = System.Drawing.Color.Cornsilk;
            this.textBox185.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox185.Location = new System.Drawing.Point(232, 482);
            this.textBox185.Name = "textBox185";
            this.textBox185.ReadOnly = true;
            this.textBox185.Size = new System.Drawing.Size(40, 22);
            this.textBox185.TabIndex = 221;
            this.textBox185.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.textBox185.Visible = false;
            // 
            // textBox186
            // 
            this.textBox186.BackColor = System.Drawing.Color.Cornsilk;
            this.textBox186.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox186.Location = new System.Drawing.Point(287, 482);
            this.textBox186.Name = "textBox186";
            this.textBox186.ReadOnly = true;
            this.textBox186.Size = new System.Drawing.Size(40, 22);
            this.textBox186.TabIndex = 222;
            this.textBox186.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.textBox186.Visible = false;
            // 
            // textBox187
            // 
            this.textBox187.BackColor = System.Drawing.Color.Cornsilk;
            this.textBox187.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox187.Location = new System.Drawing.Point(342, 482);
            this.textBox187.Name = "textBox187";
            this.textBox187.ReadOnly = true;
            this.textBox187.Size = new System.Drawing.Size(40, 22);
            this.textBox187.TabIndex = 223;
            this.textBox187.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.textBox187.Visible = false;
            // 
            // textBox188
            // 
            this.textBox188.BackColor = System.Drawing.Color.Cornsilk;
            this.textBox188.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox188.Location = new System.Drawing.Point(397, 482);
            this.textBox188.Name = "textBox188";
            this.textBox188.ReadOnly = true;
            this.textBox188.Size = new System.Drawing.Size(40, 22);
            this.textBox188.TabIndex = 224;
            this.textBox188.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.textBox188.Visible = false;
            // 
            // textBox189
            // 
            this.textBox189.BackColor = System.Drawing.Color.Cornsilk;
            this.textBox189.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox189.Location = new System.Drawing.Point(452, 482);
            this.textBox189.Name = "textBox189";
            this.textBox189.ReadOnly = true;
            this.textBox189.Size = new System.Drawing.Size(40, 22);
            this.textBox189.TabIndex = 225;
            this.textBox189.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.textBox189.Visible = false;
            // 
            // textBox190
            // 
            this.textBox190.BackColor = System.Drawing.Color.Cornsilk;
            this.textBox190.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox190.Location = new System.Drawing.Point(507, 482);
            this.textBox190.Name = "textBox190";
            this.textBox190.ReadOnly = true;
            this.textBox190.Size = new System.Drawing.Size(40, 22);
            this.textBox190.TabIndex = 226;
            this.textBox190.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.textBox190.Visible = false;
            // 
            // textBox191
            // 
            this.textBox191.BackColor = System.Drawing.Color.Cornsilk;
            this.textBox191.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox191.Location = new System.Drawing.Point(562, 482);
            this.textBox191.Name = "textBox191";
            this.textBox191.ReadOnly = true;
            this.textBox191.Size = new System.Drawing.Size(40, 22);
            this.textBox191.TabIndex = 227;
            this.textBox191.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.textBox191.Visible = false;
            // 
            // textBox192
            // 
            this.textBox192.BackColor = System.Drawing.Color.Cornsilk;
            this.textBox192.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox192.Location = new System.Drawing.Point(617, 482);
            this.textBox192.Name = "textBox192";
            this.textBox192.ReadOnly = true;
            this.textBox192.Size = new System.Drawing.Size(40, 22);
            this.textBox192.TabIndex = 228;
            this.textBox192.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.textBox192.Visible = false;
            // 
            // textBox193
            // 
            this.textBox193.BackColor = System.Drawing.Color.Cornsilk;
            this.textBox193.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox193.Location = new System.Drawing.Point(672, 482);
            this.textBox193.Name = "textBox193";
            this.textBox193.ReadOnly = true;
            this.textBox193.Size = new System.Drawing.Size(40, 22);
            this.textBox193.TabIndex = 229;
            this.textBox193.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.textBox193.Visible = false;
            // 
            // textBox194
            // 
            this.textBox194.BackColor = System.Drawing.Color.Cornsilk;
            this.textBox194.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox194.Location = new System.Drawing.Point(727, 482);
            this.textBox194.Name = "textBox194";
            this.textBox194.ReadOnly = true;
            this.textBox194.Size = new System.Drawing.Size(40, 22);
            this.textBox194.TabIndex = 230;
            this.textBox194.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.textBox194.Visible = false;
            // 
            // textBox195
            // 
            this.textBox195.BackColor = System.Drawing.Color.Cornsilk;
            this.textBox195.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox195.Location = new System.Drawing.Point(783, 482);
            this.textBox195.Name = "textBox195";
            this.textBox195.ReadOnly = true;
            this.textBox195.Size = new System.Drawing.Size(40, 22);
            this.textBox195.TabIndex = 231;
            this.textBox195.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.textBox195.Visible = false;
            // 
            // textBox196
            // 
            this.textBox196.BackColor = System.Drawing.Color.Cornsilk;
            this.textBox196.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox196.Location = new System.Drawing.Point(12, 510);
            this.textBox196.Name = "textBox196";
            this.textBox196.ReadOnly = true;
            this.textBox196.Size = new System.Drawing.Size(40, 22);
            this.textBox196.TabIndex = 232;
            this.textBox196.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.textBox196.Visible = false;
            // 
            // textBox197
            // 
            this.textBox197.BackColor = System.Drawing.Color.Cornsilk;
            this.textBox197.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox197.Location = new System.Drawing.Point(67, 510);
            this.textBox197.Name = "textBox197";
            this.textBox197.ReadOnly = true;
            this.textBox197.Size = new System.Drawing.Size(40, 22);
            this.textBox197.TabIndex = 233;
            this.textBox197.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.textBox197.Visible = false;
            // 
            // textBox198
            // 
            this.textBox198.BackColor = System.Drawing.Color.Cornsilk;
            this.textBox198.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox198.Location = new System.Drawing.Point(122, 510);
            this.textBox198.Name = "textBox198";
            this.textBox198.ReadOnly = true;
            this.textBox198.Size = new System.Drawing.Size(40, 22);
            this.textBox198.TabIndex = 234;
            this.textBox198.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.textBox198.Visible = false;
            // 
            // textBox199
            // 
            this.textBox199.BackColor = System.Drawing.Color.Cornsilk;
            this.textBox199.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox199.Location = new System.Drawing.Point(177, 510);
            this.textBox199.Name = "textBox199";
            this.textBox199.ReadOnly = true;
            this.textBox199.Size = new System.Drawing.Size(40, 22);
            this.textBox199.TabIndex = 235;
            this.textBox199.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.textBox199.Visible = false;
            // 
            // textBox200
            // 
            this.textBox200.BackColor = System.Drawing.Color.Cornsilk;
            this.textBox200.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox200.Location = new System.Drawing.Point(232, 510);
            this.textBox200.Name = "textBox200";
            this.textBox200.ReadOnly = true;
            this.textBox200.Size = new System.Drawing.Size(40, 22);
            this.textBox200.TabIndex = 236;
            this.textBox200.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.textBox200.Visible = false;
            // 
            // textBox201
            // 
            this.textBox201.BackColor = System.Drawing.Color.Cornsilk;
            this.textBox201.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox201.Location = new System.Drawing.Point(287, 510);
            this.textBox201.Name = "textBox201";
            this.textBox201.ReadOnly = true;
            this.textBox201.Size = new System.Drawing.Size(40, 22);
            this.textBox201.TabIndex = 237;
            this.textBox201.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.textBox201.Visible = false;
            // 
            // textBox202
            // 
            this.textBox202.BackColor = System.Drawing.Color.Cornsilk;
            this.textBox202.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox202.Location = new System.Drawing.Point(342, 510);
            this.textBox202.Name = "textBox202";
            this.textBox202.ReadOnly = true;
            this.textBox202.Size = new System.Drawing.Size(40, 22);
            this.textBox202.TabIndex = 238;
            this.textBox202.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.textBox202.Visible = false;
            // 
            // textBox203
            // 
            this.textBox203.BackColor = System.Drawing.Color.Cornsilk;
            this.textBox203.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox203.Location = new System.Drawing.Point(397, 510);
            this.textBox203.Name = "textBox203";
            this.textBox203.ReadOnly = true;
            this.textBox203.Size = new System.Drawing.Size(40, 22);
            this.textBox203.TabIndex = 239;
            this.textBox203.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.textBox203.Visible = false;
            // 
            // textBox204
            // 
            this.textBox204.BackColor = System.Drawing.Color.Cornsilk;
            this.textBox204.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox204.Location = new System.Drawing.Point(452, 510);
            this.textBox204.Name = "textBox204";
            this.textBox204.ReadOnly = true;
            this.textBox204.Size = new System.Drawing.Size(40, 22);
            this.textBox204.TabIndex = 240;
            this.textBox204.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.textBox204.Visible = false;
            // 
            // textBox205
            // 
            this.textBox205.BackColor = System.Drawing.Color.Cornsilk;
            this.textBox205.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox205.Location = new System.Drawing.Point(507, 510);
            this.textBox205.Name = "textBox205";
            this.textBox205.ReadOnly = true;
            this.textBox205.Size = new System.Drawing.Size(40, 22);
            this.textBox205.TabIndex = 241;
            this.textBox205.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.textBox205.Visible = false;
            // 
            // textBox206
            // 
            this.textBox206.BackColor = System.Drawing.Color.Cornsilk;
            this.textBox206.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox206.Location = new System.Drawing.Point(562, 510);
            this.textBox206.Name = "textBox206";
            this.textBox206.ReadOnly = true;
            this.textBox206.Size = new System.Drawing.Size(40, 22);
            this.textBox206.TabIndex = 242;
            this.textBox206.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.textBox206.Visible = false;
            // 
            // textBox207
            // 
            this.textBox207.BackColor = System.Drawing.Color.Cornsilk;
            this.textBox207.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox207.Location = new System.Drawing.Point(617, 510);
            this.textBox207.Name = "textBox207";
            this.textBox207.ReadOnly = true;
            this.textBox207.Size = new System.Drawing.Size(40, 22);
            this.textBox207.TabIndex = 243;
            this.textBox207.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.textBox207.Visible = false;
            // 
            // textBox208
            // 
            this.textBox208.BackColor = System.Drawing.Color.Cornsilk;
            this.textBox208.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox208.Location = new System.Drawing.Point(672, 510);
            this.textBox208.Name = "textBox208";
            this.textBox208.ReadOnly = true;
            this.textBox208.Size = new System.Drawing.Size(40, 22);
            this.textBox208.TabIndex = 244;
            this.textBox208.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.textBox208.Visible = false;
            // 
            // textBox209
            // 
            this.textBox209.BackColor = System.Drawing.Color.Cornsilk;
            this.textBox209.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox209.Location = new System.Drawing.Point(727, 510);
            this.textBox209.Name = "textBox209";
            this.textBox209.ReadOnly = true;
            this.textBox209.Size = new System.Drawing.Size(40, 22);
            this.textBox209.TabIndex = 245;
            this.textBox209.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.textBox209.Visible = false;
            // 
            // textBox210
            // 
            this.textBox210.BackColor = System.Drawing.Color.Cornsilk;
            this.textBox210.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox210.Location = new System.Drawing.Point(783, 510);
            this.textBox210.Name = "textBox210";
            this.textBox210.ReadOnly = true;
            this.textBox210.Size = new System.Drawing.Size(40, 22);
            this.textBox210.TabIndex = 246;
            this.textBox210.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.textBox210.Visible = false;
            // 
            // textBox211
            // 
            this.textBox211.BackColor = System.Drawing.Color.Cornsilk;
            this.textBox211.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox211.Location = new System.Drawing.Point(12, 538);
            this.textBox211.Name = "textBox211";
            this.textBox211.ReadOnly = true;
            this.textBox211.Size = new System.Drawing.Size(40, 22);
            this.textBox211.TabIndex = 247;
            this.textBox211.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.textBox211.Visible = false;
            // 
            // textBox212
            // 
            this.textBox212.BackColor = System.Drawing.Color.Cornsilk;
            this.textBox212.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox212.Location = new System.Drawing.Point(67, 538);
            this.textBox212.Name = "textBox212";
            this.textBox212.ReadOnly = true;
            this.textBox212.Size = new System.Drawing.Size(40, 22);
            this.textBox212.TabIndex = 248;
            this.textBox212.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.textBox212.Visible = false;
            // 
            // textBox213
            // 
            this.textBox213.BackColor = System.Drawing.Color.Cornsilk;
            this.textBox213.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox213.Location = new System.Drawing.Point(122, 538);
            this.textBox213.Name = "textBox213";
            this.textBox213.ReadOnly = true;
            this.textBox213.Size = new System.Drawing.Size(40, 22);
            this.textBox213.TabIndex = 249;
            this.textBox213.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.textBox213.Visible = false;
            // 
            // textBox214
            // 
            this.textBox214.BackColor = System.Drawing.Color.Cornsilk;
            this.textBox214.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox214.Location = new System.Drawing.Point(177, 538);
            this.textBox214.Name = "textBox214";
            this.textBox214.ReadOnly = true;
            this.textBox214.Size = new System.Drawing.Size(40, 22);
            this.textBox214.TabIndex = 250;
            this.textBox214.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.textBox214.Visible = false;
            // 
            // textBox215
            // 
            this.textBox215.BackColor = System.Drawing.Color.Cornsilk;
            this.textBox215.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox215.Location = new System.Drawing.Point(232, 538);
            this.textBox215.Name = "textBox215";
            this.textBox215.ReadOnly = true;
            this.textBox215.Size = new System.Drawing.Size(40, 22);
            this.textBox215.TabIndex = 251;
            this.textBox215.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.textBox215.Visible = false;
            // 
            // textBox216
            // 
            this.textBox216.BackColor = System.Drawing.Color.Cornsilk;
            this.textBox216.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox216.Location = new System.Drawing.Point(287, 538);
            this.textBox216.Name = "textBox216";
            this.textBox216.ReadOnly = true;
            this.textBox216.Size = new System.Drawing.Size(40, 22);
            this.textBox216.TabIndex = 252;
            this.textBox216.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.textBox216.Visible = false;
            // 
            // textBox217
            // 
            this.textBox217.BackColor = System.Drawing.Color.Cornsilk;
            this.textBox217.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox217.Location = new System.Drawing.Point(342, 538);
            this.textBox217.Name = "textBox217";
            this.textBox217.ReadOnly = true;
            this.textBox217.Size = new System.Drawing.Size(40, 22);
            this.textBox217.TabIndex = 253;
            this.textBox217.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.textBox217.Visible = false;
            // 
            // textBox218
            // 
            this.textBox218.BackColor = System.Drawing.Color.Cornsilk;
            this.textBox218.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox218.Location = new System.Drawing.Point(397, 538);
            this.textBox218.Name = "textBox218";
            this.textBox218.ReadOnly = true;
            this.textBox218.Size = new System.Drawing.Size(40, 22);
            this.textBox218.TabIndex = 254;
            this.textBox218.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.textBox218.Visible = false;
            // 
            // textBox219
            // 
            this.textBox219.BackColor = System.Drawing.Color.Cornsilk;
            this.textBox219.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox219.Location = new System.Drawing.Point(452, 538);
            this.textBox219.Name = "textBox219";
            this.textBox219.ReadOnly = true;
            this.textBox219.Size = new System.Drawing.Size(40, 22);
            this.textBox219.TabIndex = 255;
            this.textBox219.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.textBox219.Visible = false;
            // 
            // textBox220
            // 
            this.textBox220.BackColor = System.Drawing.Color.Cornsilk;
            this.textBox220.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox220.Location = new System.Drawing.Point(507, 538);
            this.textBox220.Name = "textBox220";
            this.textBox220.ReadOnly = true;
            this.textBox220.Size = new System.Drawing.Size(40, 22);
            this.textBox220.TabIndex = 256;
            this.textBox220.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.textBox220.Visible = false;
            // 
            // textBox221
            // 
            this.textBox221.BackColor = System.Drawing.Color.Cornsilk;
            this.textBox221.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox221.Location = new System.Drawing.Point(617, 538);
            this.textBox221.Name = "textBox221";
            this.textBox221.ReadOnly = true;
            this.textBox221.Size = new System.Drawing.Size(40, 22);
            this.textBox221.TabIndex = 257;
            this.textBox221.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.textBox221.Visible = false;
            // 
            // textBox222
            // 
            this.textBox222.BackColor = System.Drawing.Color.Cornsilk;
            this.textBox222.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox222.Location = new System.Drawing.Point(562, 538);
            this.textBox222.Name = "textBox222";
            this.textBox222.ReadOnly = true;
            this.textBox222.Size = new System.Drawing.Size(40, 22);
            this.textBox222.TabIndex = 257;
            this.textBox222.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.textBox222.Visible = false;
            // 
            // textBox223
            // 
            this.textBox223.BackColor = System.Drawing.Color.Cornsilk;
            this.textBox223.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox223.Location = new System.Drawing.Point(672, 538);
            this.textBox223.Name = "textBox223";
            this.textBox223.ReadOnly = true;
            this.textBox223.Size = new System.Drawing.Size(40, 22);
            this.textBox223.TabIndex = 258;
            this.textBox223.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.textBox223.Visible = false;
            // 
            // textBox224
            // 
            this.textBox224.BackColor = System.Drawing.Color.Cornsilk;
            this.textBox224.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox224.Location = new System.Drawing.Point(727, 538);
            this.textBox224.Name = "textBox224";
            this.textBox224.ReadOnly = true;
            this.textBox224.Size = new System.Drawing.Size(40, 22);
            this.textBox224.TabIndex = 259;
            this.textBox224.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.textBox224.Visible = false;
            // 
            // textBox225
            // 
            this.textBox225.BackColor = System.Drawing.Color.Cornsilk;
            this.textBox225.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox225.Location = new System.Drawing.Point(783, 538);
            this.textBox225.Name = "textBox225";
            this.textBox225.ReadOnly = true;
            this.textBox225.Size = new System.Drawing.Size(40, 22);
            this.textBox225.TabIndex = 260;
            this.textBox225.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.textBox225.Visible = false;
            // 
            // MainForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoSize = true;
            this.BackColor = System.Drawing.SystemColors.Control;
            this.ClientSize = new System.Drawing.Size(309, 241);
            this.Controls.Add(this.textBox225);
            this.Controls.Add(this.textBox224);
            this.Controls.Add(this.textBox223);
            this.Controls.Add(this.textBox222);
            this.Controls.Add(this.textBox221);
            this.Controls.Add(this.textBox220);
            this.Controls.Add(this.textBox219);
            this.Controls.Add(this.textBox218);
            this.Controls.Add(this.textBox217);
            this.Controls.Add(this.textBox216);
            this.Controls.Add(this.textBox215);
            this.Controls.Add(this.textBox214);
            this.Controls.Add(this.textBox213);
            this.Controls.Add(this.textBox212);
            this.Controls.Add(this.textBox211);
            this.Controls.Add(this.textBox210);
            this.Controls.Add(this.textBox209);
            this.Controls.Add(this.textBox208);
            this.Controls.Add(this.textBox207);
            this.Controls.Add(this.textBox206);
            this.Controls.Add(this.textBox205);
            this.Controls.Add(this.textBox204);
            this.Controls.Add(this.textBox203);
            this.Controls.Add(this.textBox202);
            this.Controls.Add(this.textBox201);
            this.Controls.Add(this.textBox200);
            this.Controls.Add(this.textBox199);
            this.Controls.Add(this.textBox198);
            this.Controls.Add(this.textBox197);
            this.Controls.Add(this.textBox196);
            this.Controls.Add(this.textBox195);
            this.Controls.Add(this.textBox194);
            this.Controls.Add(this.textBox193);
            this.Controls.Add(this.textBox192);
            this.Controls.Add(this.textBox191);
            this.Controls.Add(this.textBox190);
            this.Controls.Add(this.textBox189);
            this.Controls.Add(this.textBox188);
            this.Controls.Add(this.textBox187);
            this.Controls.Add(this.textBox186);
            this.Controls.Add(this.textBox185);
            this.Controls.Add(this.textBox184);
            this.Controls.Add(this.textBox183);
            this.Controls.Add(this.textBox182);
            this.Controls.Add(this.textBox181);
            this.Controls.Add(this.textBox180);
            this.Controls.Add(this.textBox179);
            this.Controls.Add(this.textBox178);
            this.Controls.Add(this.textBox177);
            this.Controls.Add(this.textBox176);
            this.Controls.Add(this.textBox175);
            this.Controls.Add(this.textBox174);
            this.Controls.Add(this.textBox173);
            this.Controls.Add(this.textBox172);
            this.Controls.Add(this.textBox171);
            this.Controls.Add(this.textBox170);
            this.Controls.Add(this.textBox169);
            this.Controls.Add(this.textBox168);
            this.Controls.Add(this.textBox167);
            this.Controls.Add(this.textBox166);
            this.Controls.Add(this.textBox165);
            this.Controls.Add(this.textBox164);
            this.Controls.Add(this.textBox163);
            this.Controls.Add(this.textBox162);
            this.Controls.Add(this.textBox161);
            this.Controls.Add(this.textBox160);
            this.Controls.Add(this.textBox159);
            this.Controls.Add(this.textBox158);
            this.Controls.Add(this.textBox157);
            this.Controls.Add(this.textBox156);
            this.Controls.Add(this.textBox155);
            this.Controls.Add(this.textBox154);
            this.Controls.Add(this.textBox153);
            this.Controls.Add(this.textBox152);
            this.Controls.Add(this.textBox151);
            this.Controls.Add(this.textBox150);
            this.Controls.Add(this.textBox149);
            this.Controls.Add(this.textBox148);
            this.Controls.Add(this.textBox147);
            this.Controls.Add(this.textBox146);
            this.Controls.Add(this.textBox145);
            this.Controls.Add(this.textBox144);
            this.Controls.Add(this.textBox143);
            this.Controls.Add(this.textBox142);
            this.Controls.Add(this.textBox141);
            this.Controls.Add(this.textBox140);
            this.Controls.Add(this.textBox139);
            this.Controls.Add(this.textBox138);
            this.Controls.Add(this.textBox137);
            this.Controls.Add(this.textBox136);
            this.Controls.Add(this.textBox135);
            this.Controls.Add(this.textBox134);
            this.Controls.Add(this.textBox133);
            this.Controls.Add(this.textBox132);
            this.Controls.Add(this.textBox131);
            this.Controls.Add(this.textBox130);
            this.Controls.Add(this.textBox129);
            this.Controls.Add(this.textBox128);
            this.Controls.Add(this.textBox127);
            this.Controls.Add(this.textBox126);
            this.Controls.Add(this.textBox125);
            this.Controls.Add(this.textBox124);
            this.Controls.Add(this.textBox123);
            this.Controls.Add(this.textBox122);
            this.Controls.Add(this.textBox121);
            this.Controls.Add(this.textBox120);
            this.Controls.Add(this.textBox119);
            this.Controls.Add(this.textBox118);
            this.Controls.Add(this.textBox117);
            this.Controls.Add(this.textBox116);
            this.Controls.Add(this.textBox115);
            this.Controls.Add(this.textBox114);
            this.Controls.Add(this.textBox113);
            this.Controls.Add(this.textBox112);
            this.Controls.Add(this.textBox111);
            this.Controls.Add(this.textBox110);
            this.Controls.Add(this.textBox109);
            this.Controls.Add(this.textBox108);
            this.Controls.Add(this.textBox107);
            this.Controls.Add(this.textBox106);
            this.Controls.Add(this.textBox105);
            this.Controls.Add(this.textBox104);
            this.Controls.Add(this.textBox103);
            this.Controls.Add(this.textBox102);
            this.Controls.Add(this.textBox101);
            this.Controls.Add(this.textBox100);
            this.Controls.Add(this.textBox99);
            this.Controls.Add(this.textBox98);
            this.Controls.Add(this.textBox97);
            this.Controls.Add(this.textBox96);
            this.Controls.Add(this.textBox95);
            this.Controls.Add(this.textBox94);
            this.Controls.Add(this.textBox93);
            this.Controls.Add(this.textBox92);
            this.Controls.Add(this.textBox91);
            this.Controls.Add(this.textBox90);
            this.Controls.Add(this.textBox89);
            this.Controls.Add(this.textBox88);
            this.Controls.Add(this.textBox87);
            this.Controls.Add(this.textBox86);
            this.Controls.Add(this.textBox85);
            this.Controls.Add(this.textBox84);
            this.Controls.Add(this.textBox83);
            this.Controls.Add(this.textBox82);
            this.Controls.Add(this.textBox81);
            this.Controls.Add(this.textBox80);
            this.Controls.Add(this.textBox79);
            this.Controls.Add(this.textBox78);
            this.Controls.Add(this.textBox77);
            this.Controls.Add(this.textBox76);
            this.Controls.Add(this.textBox75);
            this.Controls.Add(this.textBox74);
            this.Controls.Add(this.textBox73);
            this.Controls.Add(this.textBox72);
            this.Controls.Add(this.textBox71);
            this.Controls.Add(this.textBox70);
            this.Controls.Add(this.textBox69);
            this.Controls.Add(this.textBox68);
            this.Controls.Add(this.textBox67);
            this.Controls.Add(this.textBox66);
            this.Controls.Add(this.textBox65);
            this.Controls.Add(this.textBox64);
            this.Controls.Add(this.textBox63);
            this.Controls.Add(this.textBox62);
            this.Controls.Add(this.textBox61);
            this.Controls.Add(this.textBox60);
            this.Controls.Add(this.textBox59);
            this.Controls.Add(this.textBox58);
            this.Controls.Add(this.textBox57);
            this.Controls.Add(this.textBox56);
            this.Controls.Add(this.textBox55);
            this.Controls.Add(this.textBox54);
            this.Controls.Add(this.textBox53);
            this.Controls.Add(this.textBox52);
            this.Controls.Add(this.textBox51);
            this.Controls.Add(this.textBox50);
            this.Controls.Add(this.textBox49);
            this.Controls.Add(this.textBox48);
            this.Controls.Add(this.textBox47);
            this.Controls.Add(this.textBox46);
            this.Controls.Add(this.textBox45);
            this.Controls.Add(this.textBox44);
            this.Controls.Add(this.textBox43);
            this.Controls.Add(this.textBox42);
            this.Controls.Add(this.textBox41);
            this.Controls.Add(this.textBox40);
            this.Controls.Add(this.textBox39);
            this.Controls.Add(this.textBox38);
            this.Controls.Add(this.textBox37);
            this.Controls.Add(this.textBox36);
            this.Controls.Add(this.textBox35);
            this.Controls.Add(this.textBox34);
            this.Controls.Add(this.textBox33);
            this.Controls.Add(this.textBox32);
            this.Controls.Add(this.textBox31);
            this.Controls.Add(this.textBox30);
            this.Controls.Add(this.textBox29);
            this.Controls.Add(this.textBox28);
            this.Controls.Add(this.textBox27);
            this.Controls.Add(this.textBox26);
            this.Controls.Add(this.textBox25);
            this.Controls.Add(this.textBox24);
            this.Controls.Add(this.textBox23);
            this.Controls.Add(this.textBox22);
            this.Controls.Add(this.textBox21);
            this.Controls.Add(this.textBox20);
            this.Controls.Add(this.textBox19);
            this.Controls.Add(this.textBox18);
            this.Controls.Add(this.textBox17);
            this.Controls.Add(this.textBox16);
            this.Controls.Add(this.textBox15);
            this.Controls.Add(this.textBox14);
            this.Controls.Add(this.textBox13);
            this.Controls.Add(this.textBox12);
            this.Controls.Add(this.textBox11);
            this.Controls.Add(this.textBox10);
            this.Controls.Add(this.textBox9);
            this.Controls.Add(this.textBox8);
            this.Controls.Add(this.textBox7);
            this.Controls.Add(this.textBox6);
            this.Controls.Add(this.textBox5);
            this.Controls.Add(this.textBox4);
            this.Controls.Add(this.textBox3);
            this.Controls.Add(this.textBox2);
            this.Controls.Add(this.textBox1);
            this.Controls.Add(this.order_box);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.button_calcul);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.sum_box);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.total_boxex_box);
            this.Font = new System.Drawing.Font("Tw Cen MT", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.Name = "MainForm";
            this.SizeGripStyle = System.Windows.Forms.SizeGripStyle.Show;
            this.Text = "Carré magique";
            this.Load += new System.EventHandler(this.MainForm_Load);
            ((System.ComponentModel.ISupportInitialize)(this.serialSettingsBindingSource)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.BindingSource serialSettingsBindingSource;
        private System.Windows.Forms.TextBox order_box;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button button_calcul;
        private System.Windows.Forms.TextBox total_boxex_box;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox sum_box;
        private System.Windows.Forms.Label label2;

        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.TextBox textBox2;
        private System.Windows.Forms.TextBox textBox3;
        private System.Windows.Forms.TextBox textBox4;
        private System.Windows.Forms.TextBox textBox5;
        private System.Windows.Forms.TextBox textBox6;
        private System.Windows.Forms.TextBox textBox7;
        private System.Windows.Forms.TextBox textBox8;
        private System.Windows.Forms.TextBox textBox9;
        private System.Windows.Forms.TextBox textBox10;
        private System.Windows.Forms.TextBox textBox11;
        private System.Windows.Forms.TextBox textBox12;
        private System.Windows.Forms.TextBox textBox13;
        private System.Windows.Forms.TextBox textBox14;
        private System.Windows.Forms.TextBox textBox15;
        private System.Windows.Forms.TextBox textBox16;
        private System.Windows.Forms.TextBox textBox17;
        private System.Windows.Forms.TextBox textBox18;
        private System.Windows.Forms.TextBox textBox19;
        private System.Windows.Forms.TextBox textBox20;
        private System.Windows.Forms.TextBox textBox21;
        private System.Windows.Forms.TextBox textBox22;
        private System.Windows.Forms.TextBox textBox23;
        private System.Windows.Forms.TextBox textBox24;
        private System.Windows.Forms.TextBox textBox25;
        private System.Windows.Forms.TextBox textBox26;
        private System.Windows.Forms.TextBox textBox27;
        private System.Windows.Forms.TextBox textBox28;
        private System.Windows.Forms.TextBox textBox29;
        private System.Windows.Forms.TextBox textBox30;
        private System.Windows.Forms.TextBox textBox31;
        private System.Windows.Forms.TextBox textBox32;
        private System.Windows.Forms.TextBox textBox33;
        private System.Windows.Forms.TextBox textBox34;
        private System.Windows.Forms.TextBox textBox35;
        private System.Windows.Forms.TextBox textBox36;
        private System.Windows.Forms.TextBox textBox37;
        private System.Windows.Forms.TextBox textBox38;
        private System.Windows.Forms.TextBox textBox39;
        private System.Windows.Forms.TextBox textBox40;
        private System.Windows.Forms.TextBox textBox41;
        private System.Windows.Forms.TextBox textBox42;
        private System.Windows.Forms.TextBox textBox43;
        private System.Windows.Forms.TextBox textBox44;
        private System.Windows.Forms.TextBox textBox45;
        private System.Windows.Forms.TextBox textBox46;
        private System.Windows.Forms.TextBox textBox47;
        private System.Windows.Forms.TextBox textBox48;
        private System.Windows.Forms.TextBox textBox49;
        private System.Windows.Forms.TextBox textBox50;
        private System.Windows.Forms.TextBox textBox51;
        private System.Windows.Forms.TextBox textBox52;
        private System.Windows.Forms.TextBox textBox53;
        private System.Windows.Forms.TextBox textBox54;
        private System.Windows.Forms.TextBox textBox55;
        private System.Windows.Forms.TextBox textBox56;
        private System.Windows.Forms.TextBox textBox57;
        private System.Windows.Forms.TextBox textBox58;
        private System.Windows.Forms.TextBox textBox59;
        private System.Windows.Forms.TextBox textBox60;
        private System.Windows.Forms.TextBox textBox61;
        private System.Windows.Forms.TextBox textBox62;
        private System.Windows.Forms.TextBox textBox63;
        private System.Windows.Forms.TextBox textBox64;
        private System.Windows.Forms.TextBox textBox65;
        private System.Windows.Forms.TextBox textBox66;
        private System.Windows.Forms.TextBox textBox67;
        private System.Windows.Forms.TextBox textBox68;
        private System.Windows.Forms.TextBox textBox69;
        private System.Windows.Forms.TextBox textBox70;
        private System.Windows.Forms.TextBox textBox71;
        private System.Windows.Forms.TextBox textBox72;
        private System.Windows.Forms.TextBox textBox73;
        private System.Windows.Forms.TextBox textBox74;
        private System.Windows.Forms.TextBox textBox75;
        private System.Windows.Forms.TextBox textBox76;
        private System.Windows.Forms.TextBox textBox77;
        private System.Windows.Forms.TextBox textBox78;
        private System.Windows.Forms.TextBox textBox79;
        private System.Windows.Forms.TextBox textBox80;
        private System.Windows.Forms.TextBox textBox81;
        private System.Windows.Forms.TextBox textBox82;
        private System.Windows.Forms.TextBox textBox83;
        private System.Windows.Forms.TextBox textBox84;
        private System.Windows.Forms.TextBox textBox85;
        private System.Windows.Forms.TextBox textBox86;
        private System.Windows.Forms.TextBox textBox87;
        private System.Windows.Forms.TextBox textBox88;
        private System.Windows.Forms.TextBox textBox89;
        private System.Windows.Forms.TextBox textBox90;
        private System.Windows.Forms.TextBox textBox91;
        private System.Windows.Forms.TextBox textBox92;
        private System.Windows.Forms.TextBox textBox93;
        private System.Windows.Forms.TextBox textBox94;
        private System.Windows.Forms.TextBox textBox95;
        private System.Windows.Forms.TextBox textBox96;
        private System.Windows.Forms.TextBox textBox97;
        private System.Windows.Forms.TextBox textBox98;
        private System.Windows.Forms.TextBox textBox99;
        private System.Windows.Forms.TextBox textBox100;
        private System.Windows.Forms.TextBox textBox101;
        private System.Windows.Forms.TextBox textBox102;
        private System.Windows.Forms.TextBox textBox103;
        private System.Windows.Forms.TextBox textBox104;
        private System.Windows.Forms.TextBox textBox105;
        private System.Windows.Forms.TextBox textBox106;
        private System.Windows.Forms.TextBox textBox107;
        private System.Windows.Forms.TextBox textBox108;
        private System.Windows.Forms.TextBox textBox109;
        private System.Windows.Forms.TextBox textBox110;
        private System.Windows.Forms.TextBox textBox111;
        private System.Windows.Forms.TextBox textBox112;
        private System.Windows.Forms.TextBox textBox113;
        private System.Windows.Forms.TextBox textBox114;
        private System.Windows.Forms.TextBox textBox115;
        private System.Windows.Forms.TextBox textBox116;
        private System.Windows.Forms.TextBox textBox117;
        private System.Windows.Forms.TextBox textBox118;
        private System.Windows.Forms.TextBox textBox119;
        private System.Windows.Forms.TextBox textBox120;
        private System.Windows.Forms.TextBox textBox121;
        private System.Windows.Forms.TextBox textBox122;
        private System.Windows.Forms.TextBox textBox123;
        private System.Windows.Forms.TextBox textBox124;
        private System.Windows.Forms.TextBox textBox125;
        private System.Windows.Forms.TextBox textBox126;
        private System.Windows.Forms.TextBox textBox127;
        private System.Windows.Forms.TextBox textBox128;
        private System.Windows.Forms.TextBox textBox129;
        private System.Windows.Forms.TextBox textBox130;
        private System.Windows.Forms.TextBox textBox131;
        private System.Windows.Forms.TextBox textBox132;
        private System.Windows.Forms.TextBox textBox133;
        private System.Windows.Forms.TextBox textBox134;
        private System.Windows.Forms.TextBox textBox135;
        private System.Windows.Forms.TextBox textBox136;
        private System.Windows.Forms.TextBox textBox137;
        private System.Windows.Forms.TextBox textBox138;
        private System.Windows.Forms.TextBox textBox139;
        private System.Windows.Forms.TextBox textBox140;
        private System.Windows.Forms.TextBox textBox141;
        private System.Windows.Forms.TextBox textBox142;
        private System.Windows.Forms.TextBox textBox143;
        private System.Windows.Forms.TextBox textBox144;
        private System.Windows.Forms.TextBox textBox145;
        private System.Windows.Forms.TextBox textBox146;
        private System.Windows.Forms.TextBox textBox147;
        private System.Windows.Forms.TextBox textBox148;
        private System.Windows.Forms.TextBox textBox149;
        private System.Windows.Forms.TextBox textBox150;
        private System.Windows.Forms.TextBox textBox151;
        private System.Windows.Forms.TextBox textBox152;
        private System.Windows.Forms.TextBox textBox153;
        private System.Windows.Forms.TextBox textBox154;
        private System.Windows.Forms.TextBox textBox155;
        private System.Windows.Forms.TextBox textBox156;
        private System.Windows.Forms.TextBox textBox157;
        private System.Windows.Forms.TextBox textBox158;
        private System.Windows.Forms.TextBox textBox159;
        private System.Windows.Forms.TextBox textBox160;
        private System.Windows.Forms.TextBox textBox161;
        private System.Windows.Forms.TextBox textBox162;
        private System.Windows.Forms.TextBox textBox163;
        private System.Windows.Forms.TextBox textBox164;
        private System.Windows.Forms.TextBox textBox165;
        private System.Windows.Forms.TextBox textBox166;
        private System.Windows.Forms.TextBox textBox167;
        private System.Windows.Forms.TextBox textBox168;
        private System.Windows.Forms.TextBox textBox169;
        private System.Windows.Forms.TextBox textBox170;
        private System.Windows.Forms.TextBox textBox171;
        private System.Windows.Forms.TextBox textBox172;
        private System.Windows.Forms.TextBox textBox173;
        private System.Windows.Forms.TextBox textBox174;
        private System.Windows.Forms.TextBox textBox175;
        private System.Windows.Forms.TextBox textBox176;
        private System.Windows.Forms.TextBox textBox177;
        private System.Windows.Forms.TextBox textBox178;
        private System.Windows.Forms.TextBox textBox179;
        private System.Windows.Forms.TextBox textBox180;
        private System.Windows.Forms.TextBox textBox181;
        private System.Windows.Forms.TextBox textBox182;
        private System.Windows.Forms.TextBox textBox183;
        private System.Windows.Forms.TextBox textBox184;
        private System.Windows.Forms.TextBox textBox185;
        private System.Windows.Forms.TextBox textBox186;
        private System.Windows.Forms.TextBox textBox187;
        private System.Windows.Forms.TextBox textBox188;
        private System.Windows.Forms.TextBox textBox189;
        private System.Windows.Forms.TextBox textBox190;
        private System.Windows.Forms.TextBox textBox191;
        private System.Windows.Forms.TextBox textBox192;
        private System.Windows.Forms.TextBox textBox193;
        private System.Windows.Forms.TextBox textBox194;
        private System.Windows.Forms.TextBox textBox195;
        private System.Windows.Forms.TextBox textBox196;
        private System.Windows.Forms.TextBox textBox197;
        private System.Windows.Forms.TextBox textBox198;
        private System.Windows.Forms.TextBox textBox199;
        private System.Windows.Forms.TextBox textBox200;
        private System.Windows.Forms.TextBox textBox201;
        private System.Windows.Forms.TextBox textBox202;
        private System.Windows.Forms.TextBox textBox203;
        private System.Windows.Forms.TextBox textBox204;
        private System.Windows.Forms.TextBox textBox205;
        private System.Windows.Forms.TextBox textBox206;
        private System.Windows.Forms.TextBox textBox207;
        private System.Windows.Forms.TextBox textBox208;
        private System.Windows.Forms.TextBox textBox209;
        private System.Windows.Forms.TextBox textBox210;
        private System.Windows.Forms.TextBox textBox211;
        private System.Windows.Forms.TextBox textBox212;
        private System.Windows.Forms.TextBox textBox213;
        private System.Windows.Forms.TextBox textBox214;
        private System.Windows.Forms.TextBox textBox215;
        private System.Windows.Forms.TextBox textBox216;
        private System.Windows.Forms.TextBox textBox217;
        private System.Windows.Forms.TextBox textBox218;
        private System.Windows.Forms.TextBox textBox219;
        private System.Windows.Forms.TextBox textBox220;
        private System.Windows.Forms.TextBox textBox221;
        private System.Windows.Forms.TextBox textBox222;
        private System.Windows.Forms.TextBox textBox223;
        private System.Windows.Forms.TextBox textBox224;
        private System.Windows.Forms.TextBox textBox225;
    }
}

